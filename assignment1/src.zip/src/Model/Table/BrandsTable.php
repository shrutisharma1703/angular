<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Brands Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Brands
 * @property \Cake\ORM\Association\BelongsToMany $Users
 *
 * @method \App\Model\Entity\Brand get($primaryKey, $options = [])
 * @method \App\Model\Entity\Brand newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Brand[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Brand|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Brand patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Brand[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Brand findOrCreate($search, callable $callback = null, $options = [])
 */

class BrandsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('brands');
        $this->setDisplayField('brand_id');
        $this->setPrimaryKey('brand_id');
        
        $this->belongsToMany('Users', [
            'foreignKey' => 'brand_id',
            'targetForeignKey' => 'user_id',
            'joinTable' => 'users_brands'
        ]);
        $this->belongsTo('Brands', [
            'foreignKey' => 'brand_id',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('Menues', [
            'foreignKey' => 'brand_id',
        ]);
        
        $this->hasMany('Packshots', [
            'foreignKey' => 'brand_id',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->notEmpty('brand_name', 'Please provide a brand name')
            ->add('brand_name', [
                'minLength' =>
            [
                'rule' => ['minLength', 3],
                MESSAGE => 'Brand name must have atleast 3 characters',
            ],
            'maxLength' =>
            [
                'rule' => ['maxLength', 50],
                MESSAGE => 'Brand name cannot be too long.',
            ],       
            ]);

        $validator
            ->notEmpty('theme_color');

        $validator
            ->notEmpty('right_content_bg_color');
         
        $validator
            ->notEmpty('right_content_view_color');
            
        $validator
            ->notEmpty('packshot_color');
            
        $validator
            ->notEmpty('profile_bg_color');
            
        $validator
            ->notEmpty('profile_image_border_color');
            
        $validator
            ->notEmpty('profile_image_outer_border_color');
            
        $validator
            ->notEmpty('listing_button_bg_color');
            
        $validator
            ->notEmpty('listing_button_title_color');

        $validator
            ->notEmpty('button_image');

        $validator
            ->notEmpty('logo_image');

        $validator
            ->notEmpty('packshot_image');
           
         $validator
            ->notEmpty('advert_pdf_path');
            
        $validator
            ->integer('is_deleted')
            ->allowEmpty('is_deleted');

        $validator
            ->dateTime('created_at')
            ->allowEmpty('created_at');

        $validator
            ->dateTime('updated_at')
            ->allowEmpty('updated_at');

        return $validator;
    }
    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['brand_id'], 'Brands'));

        return $rules;
    }
   
}

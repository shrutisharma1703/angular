<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\I18n\Time;

/**
 * Doctors Model
 *
 * @method \App\Model\Entity\Doctor get($primaryKey, $options = [])
 * @method \App\Model\Entity\Doctor newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Doctor[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Doctor|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Doctor patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Doctor[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Doctor findOrCreate($search, callable $callback = null, $options = [])
 */
class DoctorsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('doctors');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');
        $this->belongsTo('Practices', [
            'foreignKey' => 'practice_id'
        ]);
        $this->belongsTo('Regions', [
            'foreignKey' => 'region_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Suburbs', [
            'foreignKey' => 'suburb_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsToMany('Users', [
            'foreignKey' => 'doctor_id',
            'targetForeignKey' => 'user_id',
            'joinTable' => 'users_doctors'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->notEmpty('first_name', 'Please provide a First name')
            ->add('first_name', [
                'minLength' =>
            [
                'rule' => ['minLength', 3],
                MESSAGE => 'First name must have atleast 3 characters',
            ],
            'maxLength' =>
            [
                'rule' => ['maxLength', 50],
                MESSAGE => 'First name cannot be too long.',
            ],       
            ]);
        

        $validator
            ->allowEmpty('last_name')
            ->add('last_name', [
                'minLength' =>
            [
                'rule' => ['minLength', 3],
                MESSAGE => 'Last name must have atleast 3 characters',
            ],
            'maxLength' =>
            [
                'rule' => ['maxLength', 50],
                MESSAGE => 'Last name cannot be too long.',
            ],       
            ]);

        $validator
            ->integer('practice_id')
            ->notEmpty('region_id');
            
        $validator
            ->integer('practice_id')
            ->notEmpty('suburb_id');
            
        $validator
            ->integer('practice_id')
            ->notEmpty('practice_id');

        $validator
            ->integer('is_deleted')
            ->allowEmpty('is_deleted');

        $validator
            ->dateTime('created_at')
            ->allowEmpty('created_at');

        $validator
            ->dateTime('updated_at')
            ->allowEmpty('updated_at');

        return $validator;
    }
          
}

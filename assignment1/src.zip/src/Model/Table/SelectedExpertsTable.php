<?php
namespace App\Model\Table;

use ArrayObject;
use Cake\Event\Event;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;


class SelectedExpertsTable extends Table
{

  /**
   * Initialize method
   *
   * @param array $config The configuration for the Table.
   * @return void
   */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('selected_experts');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('Users', [
          'foreignKey' => 'user_id',
          'joinType' => 'INNER',
        ]);
        $this->belongsTo('Doctors', [
          'foreignKey' => 'doctor_id',
          'joinType' => 'INNER',
        ]);
        $this->belongsTo('Suburbs', [
          'foreignKey' => 'suburb_id',
          'joinType' => 'INNER',
        ]);
        $this->belongsTo('Practices', [
          'foreignKey' => 'practice_id',
          'joinType' => 'INNER',
        ]);
    }

  /**
   * Default validation rules.
   *
   * @param \Cake\Validation\Validator $validator Validator instance.
   * @return \Cake\Validation\Validator
   */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');
      
        $validator
            ->notEmpty('user_id');
        
        $validator
            ->notEmpty('suburb_id');
        
        $validator
            ->notEmpty('practice_id');
        
        $validator
            ->notEmpty('doctor_id');


        return $validator;
    }

  /**
   * Returns a rules checker object that will be used for validating
   * application integrity.
   *
   * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
   * @return \Cake\ORM\RulesChecker
   */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        $rules->add($rules->existsIn(['doctor_id'], 'Doctors'));
        $rules->add($rules->existsIn(['practice_id'], 'Practices'));
        $rules->add($rules->existsIn(['suburb_id'], 'Suburbs'));

        return $rules;
    }

    /**
    * Trim Request Data Before Building Entities
    *
    * @param ArrayObject $event
    * @param \Cake\Event\Event $data Request object
    * @param ArrayObject $options
    * @return Object Request object
    */
    public function beforeMarshal(Event $event, ArrayObject $data, ArrayObject $options)
    {
        foreach ($data as $key => $value) {
            if (is_string($value)) {
                $data[$key] = trim($value);
            }
        }
    }
}

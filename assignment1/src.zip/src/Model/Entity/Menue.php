<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Menue Entity
 *
 * @property int $menues_id
 * @property string $name
 * @property int $brand_id
 * @property int $parent_id
 * @property string $pdf_path
 * @property int $is_deleted
 * @property \Cake\I18n\Time $created_at
 * @property \Cake\I18n\Time $updated_at
 *
 * @property \App\Model\Entity\Menue $menue
 * @property \App\Model\Entity\Brand $brand
 * @property \App\Model\Entity\ParentMenue $parent_menue
 * @property \App\Model\Entity\ChildMenue[] $child_menues
 */
class Menue extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        //'menues_id' => false
    ];
}

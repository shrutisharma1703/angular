<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Brand Entity
 *
 * @property int $brand_id
 * @property string $brand_name
 * @property string $theme_color
 * @property string $right_content_bg_color
 * @property string $right_content_view_color
 * @property string $packshot_color
 * @property string $profile_bg_color
 * @property string $profile_image_border_color
 * @property string $profile_image_outer_border_color
 * @property string $listing_button_bg_color
 * @property string $listing_button_title_color
 * @property string $button_image
 * @property string $logo_image
 * @property string $packshot_image
 * @property string $advert_pdf_path
 * @property int $order_no
 * @property int $is_deleted
 * @property \Cake\I18n\Time $created_at
 * @property \Cake\I18n\Time $updated_at
 *
 * @property \App\Model\Entity\Brand $brand
 * @property \App\Model\Entity\User[] $users
 */
class Brand extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'brand_id' => false
    ];
}

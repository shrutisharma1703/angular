<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * SelectedExperts Controller
 *
 * @property \App\Model\Table\SelectedExpertsTable $SelectedExperts
 */
class SelectedExpertsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $SelectedExperts = $this->paginate($this->SelectedExperts);
        $this->set(compact('SelectedExperts'));
        $this->set('_serialize', ['SelectedExperts']);  
    }

    /**
     * View method
     *
     * @param string|null $id SelectedExperts id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $SelectedExperts = $this->SelectedExperts->get($id, [
            'contain' => []
        ]);
        $this->set('SelectedExperts', $SelectedExperts);
        $this->set('_serialize', ['SelectedExperts']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $SelectedExperts = $this->SelectedExperts->newEntity();
        if ($this->request->is('post')) {
            $SelectedExperts = $this->SelectedExperts->patchEntity($SelectedExperts, $this->request->getData());
            if ($this->SelectedExperts->save($SelectedExperts)) {
                $this->Flash->success(__('The SelectedExperts has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The SelectedExperts could not be saved. Please, try again.'));
        }
        $this->set(compact('SelectedExperts'));
        $this->set('_serialize', ['SelectedExperts']);
    }

    /**
     * Edit method
     *
     * @param string|null $id SelectedExperts id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $SelectedExperts = $this->SelectedExperts->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $SelectedExperts = $this->SelectedExperts->patchEntity($SelectedExperts, $this->request->getData());
            if ($this->SelectedExperts->save($SelectedExperts)) {
                $this->Flash->success(__('The SelectedExperts has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The SelectedExperts could not be saved. Please, try again.'));
        }
        $this->set(compact('SelectedExperts'));
        $this->set('_serialize', ['SelectedExperts']);
    }

    /**
     * Delete method
     *
     * @param string|null $id SelectedExperts id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $SelectedExperts = $this->SelectedExperts->get($id);
        if ($this->SelectedExperts->delete($SelectedExperts)) {
            $this->Flash->success(__('The SelectedExperts has been deleted.'));
        } else {
            $this->Flash->error(__('The SelectedExperts could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}

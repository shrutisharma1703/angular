<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Brands Controller
 *
 * @property \App\Model\Table\BrandsTable $Brands
 */
class BrandsController extends AppController
{
    
    public function initialize(){
        parent::initialize();
        $this->viewBuilder()->setLayout('admin');
    } 

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->loadModel('Menues'); 
        $brands = $this->paginate($this->Brands);
        $this->set(compact('brands'));
        $this->set('_serialize', ['brands']);
    }

    /**
     * View method
     *
     * @param string|null $id Brand id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $brand = $this->Brands->get($id, [
            'contain' => []
        ]);
        $brand['advert_pdf']  = $this->Common->readVideo(AWS_BUCKET_DEV, BRAND_BUCKET.DIRECTORY_SEPARATOR.$brand->advert_pdf_path);
        $this->set('brand', $brand);
        $this->set('_serialize', ['brand']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $brand = $this->Brands->newEntity();
        if ($this->request->is('post')) {
            $query = $this->Brands->find();
            $order = $query->select(['order_no' => $query->func()->max('order_no')])->first();          
            $this->request->data['order_no'] = ($order['order_no'])+1;  
            $this->request->data['created_at'] = $this->request->data['created_at'] = date("Y-m-d H:i:s");          
            $this->request->data['updated_at'] = $this->request->data['updated_at'] = date("Y-m-d H:i:s");    
            $buttonImage = $this->Common->imageFileValues($this->request->getData('button_image'));
            $logoImage = $this->Common->imageFileValues($this->request->getData('logo_image'));
            $packshotImage = $this->Common->imageFileValues($this->request->getData('packshot_image'));
            $advertPdf = $this->Common->imageFileValues($this->request->getData('advert_pdf_path'));
            //check  Button image file
            if ($buttonImage[TEMP_NAME] == '') {
                unset($this->request->data['button_image']);
            } else {
                $this->request->data['button_image'] = $buttonImage['name'];
            }
            
            //check  logo image file
            if ($logoImage[TEMP_NAME] == '') {
                unset($this->request->data['logo_image']);
            } else {
                $this->request->data['logo_image'] = $logoImage['name'];
            }
            
            //check  packshot image file
            if ($packshotImage[TEMP_NAME] == '') {
                unset($this->request->data['packshot_image']);
            } else {
                $this->request->data['packshot_image'] = $packshotImage['name'];
            }
            
            //check  Pdf Path file
            if ($advertPdf[TEMP_NAME] == '') {
                unset($this->request->data['advert_pdf_path']);
            } else {
                $this->request->data['advert_pdf_path'] = $advertPdf['name'];
            }
            $arr_ext = array('jpg', 'jpeg', 'gif', 'png', 'bmp');
            $arr_ext_pdf = array('pdf');
            //set allowed extensions
            if((!empty($this->request->data['image_path']) && !in_array($buttonImage['ext'], $arr_ext))|| (!empty($this->request->data['advert_pdf_path']) && !in_array($advertPdf['ext'], $arr_ext_pdf)))
            {
                $this->Flash->error(__(INVALID_FILE));
            }
            if((!empty($this->request->data['logo_image']) && !in_array($logoImage['ext'], $arr_ext))|| (!empty($this->request->data['packshot_image']) && !in_array($packshotImage['ext'], $arr_ext)))
            {
                $this->Flash->error(__(INVALID_FILE));
            }
            else{
                    $brand = $this->Brands->patchEntity($brand, $this->request->getData());
                    if ($this->Brands->save($brand)) {
                        if ($buttonImage[TEMP_NAME] != '') {
                            try {
                                $this->Common->imageFileUpload($buttonImage[TEMP_NAME], $buttonImage['name'], $buttonImage['size'], $buttonImage['ext'], 'buttonImage');
                            } catch (Exception $ex) {
                                $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                            }
                        }
                        
                        if ($logoImage[TEMP_NAME] != '') {
                            try {
                                $this->Common->imageFileUpload($logoImage[TEMP_NAME], $logoImage['name'], $logoImage['size'],   $logoImage['ext'], 'logoImage');
                            } catch (Exception $ex) {
                                $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                            }
                        }
                        
                        if ($packshotImage[TEMP_NAME] != '') {
                            try {
                                $this->Common->imageFileUpload($packshotImage[TEMP_NAME], $packshotImage['name'], $packshotImage['size'], $packshotImage['ext'], 'packshotImage');
                            } catch (Exception $ex) {
                                $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                            }
                        }
                        
                        if ($advertPdf[TEMP_NAME] != '') {
                            try {
                                $this->Common->awsBrandUpload($advertPdf[TEMP_NAME], $advertPdf['name'], $advertPdf['size'],    $advertPdf['ext'], 'advertPdf');
                            } catch (Exception $ex) {
                                $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                            }
                        }
                        
                        $this->Flash->success(__('The brand has been saved.'));

                        return $this->redirect(['action' => 'index']);
                    }
                    $this->Flash->error(__('The brand could not be saved. Please, try again.'));
                }
        }
        $this->set(compact('brand'));
        $this->set('_serialize', ['brand']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Brand id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $brand = $this->Brands->get($id, [
            'contain' => []
        ]);
        $brand['advert_pdf']  = $this->Common->readVideo(AWS_BUCKET_DEV, BRAND_BUCKET.DIRECTORY_SEPARATOR.$brand->advert_pdf_path);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $buttonImage = $this->Common->imageFileValues($this->request->getData('button_image'));
            $logoImage = $this->Common->imageFileValues($this->request->getData('logo_image'));
            $packshotImage = $this->Common->imageFileValues($this->request->getData('packshot_image'));
            $advertPdf = $this->Common->imageFileValues($this->request->getData('advert_pdf_path'));
            $this->request->data['updated_at'] = $this->request->data['updated_at'] = date("Y-m-d H:i:s");  
            //check  Button image file
            if ($buttonImage[TEMP_NAME] == '') {
                unset($this->request->data['button_image']);
            } else {
                $this->request->data['button_image'] = $buttonImage['name'];
            }
            
            //check  logo image file
            if ($logoImage[TEMP_NAME] == '') {
                unset($this->request->data['logo_image']);
            } else {
                $this->request->data['logo_image'] = $logoImage['name'];
            }
            
            //check  packshot image file
            if ($packshotImage[TEMP_NAME] == '') {
                unset($this->request->data['packshot_image']);
            } else {
                $this->request->data['packshot_image'] = $packshotImage['name'];
            }
            
            if ($advertPdf[TEMP_NAME] == '') {
                unset($this->request->data['advert_pdf_path']);
            } else {
                $this->request->data['advert_pdf_path'] = $advertPdf['name'];
            }
            $arr_ext_pdf = array('pdf');
            $arr_ext = array('jpg', 'jpeg', 'gif', 'png', 'bmp');

            
            //set allowed extensions
            if((!empty($this->request->data['image_path']) && !in_array($buttonImage['ext'], $arr_ext))|| (!empty($this->request->data['advert_pdf_path']) && !in_array($advertPdf['ext'], $arr_ext_pdf)))
            {
                $this->Flash->error(__(INVALID_FILE));
            }
            if((!empty($this->request->data['logo_image']) && !in_array($logoImage['ext'], $arr_ext))|| (!empty($this->request->data['packshot_image']) && !in_array($packshotImage['ext'], $arr_ext)))
            {
                $this->Flash->error(__(INVALID_FILE));
            }
            
            else {
                    $brand = $this->Brands->patchEntity($brand, $this->request->getData());
                    if ($this->Brands->save($brand)) {
                        if ($buttonImage[TEMP_NAME] != '') {
                            try {
                                $this->Common->imageFileUpload($buttonImage[TEMP_NAME], $buttonImage['name'], $buttonImage['size'], $buttonImage['ext'], 'buttonImage');
                            } catch (Exception $ex) {
                                $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                            }
                        }
                        
                        if ($logoImage[TEMP_NAME] != '') {
                            try {
                                $this->Common->imageFileUpload($logoImage[TEMP_NAME], $logoImage['name'], $logoImage['size'], $logoImage['ext'], 'logoImage');
                            } catch (Exception $ex) {
                                $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                            }
                        }
                        
                        if ($packshotImage[TEMP_NAME] != '') {
                            try {
                                $this->Common->imageFileUpload($packshotImage[TEMP_NAME], $packshotImage['name'],   $packshotImage['size'], $packshotImage['ext'], 'packshotImage');
                            } catch (Exception $ex) {
                                $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                            }
                        }
                        
                        if ($advertPdf[TEMP_NAME] != '') {
                                try {
                                    $this->Common->awsBrandUpload($advertPdf[TEMP_NAME], $advertPdf['name'], $advertPdf['size'], $advertPdf['ext'], 'advertPdf');
                                } catch (Exception $ex) {
                                    $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                                }
                            }
                        $this->Flash->success(__('The brand has been saved.'));

                        return $this->redirect(['action' => 'index']);
                    }
                $this->Flash->error(__('The brand could not be saved. Please, try again.'));
            }
            
        }
        $this->set(compact('brand'));
        $this->set('_serialize', ['brand']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Brand id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $brand = $this->Brands->get($id);
        if ($this->Brands->delete($brand)) {
            $this->Flash->success(__('The brand has been deleted.'));
        } else {
            $this->Flash->error(__('The brand could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
    
    public function setOrder()
    {
        $this->viewBuilder()->setLayout(ADMIN);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = [];
        foreach ($this->request->getData('brand_id') as $order => $brand_id) {
            $data[] = ['order_no' => $order+1, 'brand_id' => $brand_id];
        }
        $brands = $this->paginate($this->Brands);
        $this->Brands->patchEntities($brands, $data);
        if ($this->Brands->saveMany($brands)) {
            $this->Flash->success(__(BRAND_ORDER));
            return $this->redirect(['action' => 'index']);
        }
        }
        $brands = $this->paginate($this->Brands, ['order' => ['order_no' => 'asc']]);
        $this->set(compact('brands'));
    }
    
     public function toggleStatus()
      {
        $this->autoRender = false;
        if ($this->request->is(['patch', 'post', 'put'])) {
          $data = [];
          $status = $this->request->getData('status');
          foreach ($this->request->getData('ids') as $user_id) {
            $data[] = ['is_deleted' => $status, 'brand_id' => $user_id];
          }
          $brands = $this->Brands->find()->where(['brand_id in' => $this->request->getData('ids')]);
          $this->Brands->patchEntities($brands, $data);
          if ($this->Brands->saveMany($brands)) {
            echo DONE;
          } else {
            echo NOT_DONE;
          }
        }
      }
  
  
   /**
   * Show method
   *
   * @return \Cake\Network\Response|null
   */
  public function show()
  {
    $limit = ADMIN_PAGINATION_LIMIT;
    $offset = ($this->request->query(START)) ? $this->request->query(START) : 0;
    $conditions = $order = [];
    if ($this->request->query('order') && $this->request->query('order.0')) {
      {
        switch ($this->request->query('order.0.column')) {
          case 0:
            $order = ['Brands.brand_name ' . $this->request->query('order.0.dir')];
            break;
          case 1:
            $order = ['Brands.created_at ' . $this->request->query('order.0.dir')];
            break;
          default:
            $order = ['Brands.brand_id DESC'];
            break;
        }
      }
    } else {
      $order = ['Brands.order_no ASC'];
    }
    if ($this->request->query('search.value')) {
        $conditions[] = ['Brands.brand_name LIKE' => '%' . $this->request->query('search.value') . '%'];
    }
    
    $totalBrands = $this->Brands->find('all', ['conditions' => $conditions]);
    $brands = $this->Brands->find('all', [
      'conditions' => $conditions,
      'offset' => $offset,
      'limit' => $limit,
      'order' => $order,
    ]);
    
    $data = [];
    $draw = 0;
    $recordsTotal = $totalBrands->count();
    $recordsFiltered = $brands->count();
   foreach ($brands as $brand) {
      $record = [];
      $record[] = $brand->brand_name;
      $record[] = $brand->order_no;
      $record[] = date('Y-m-d', strtotime($brand->created_at));
      $record[] = '&nbsp;&nbsp;<a title="View" href="/Brands/view/' . $brand->brand_id . '"><i class="fa fac-info"></i></a>&nbsp;&nbsp;<a title="Edit" href="/Brands/edit/' . $brand->brand_id . '"><i class="fa fac-edit"></i></a>&nbsp;&nbsp;<a onclick="toggleStatus(\'/Brands/toggleStatus\',\'' . $brand->brand_id . '\')" href="javascript:void(0)" title="' . (($brand->is_deleted) ? 'Deactivate' : 'Activate') . '" ><i class="active_' . $brand->brand_id . ' fa fac-' . (($brand->is_deleted) ? 'deactive' : 'active') . '-action"></i></a>';
      $data[] = $record;
    }
    $resultJson = json_encode(compact('draw', 'data', 'recordsTotal', 'recordsFiltered', START, 'length'));
    $this->response->type('json');
    $this->response->body($resultJson);
    return $this->response;
  }

}

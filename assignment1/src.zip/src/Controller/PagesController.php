<?php
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

/**
 * Static content controller
 *
 * This controller will render views from Template/Pages/
 *
 * @link http://book.cakephp.org/3.0/en/controllers/pages-controller.html
 */
class PagesController extends AppController
{
    
    public function initialize(){
        parent::initialize();
        $this->viewBuilder()->setLayout('admin');
    } 
      /**
       * @param $url_key
       */
    public function index($url_key = '') {
    }
     
    
    public function home() {
        $this->set('home_page',true);
        $data = array();
        if ($this->request->is(['patch', 'post', 'put'])) {
            if($this->request->getData('users')){
                $data['user_id'] = (!empty($this->request->getData('users')))?$this->request->getData('users'):'';
            }
            if($this->request->getData('doctors')){
                $data['doctor_id'] = (!empty($this->request->getData('doctors')))?$this->request->getData('doctors'):'';
            }
            if($this->request->getData('start_at')){
                $data['start_at'] = (!empty($this->request->getData('start_at')))?$this->request->getData('start_at'):'';
            }
            if($this->request->getData('end_at')){
                $data['end_at'] = (!empty($this->request->getData('end_at')))?$this->request->getData('end_at'):'';
            }
        }
        
        //OTO category Count clicks
        $this->getCategoryGraph($data);
        
        //Get RDI Count
        $this->getRdiGraph($data);
        
        //Packshot
        $this->getPackshotGraph($data);
        
        //Risk graphs
        $this->getRiskGraph($data); 
        $users = $this->Common->fetchList('Users', 'role', 1);
        $doctors = $this->Common->fetchList('Doctors', 'is_deleted', 0);
        $this->set(compact('users','doctors'));    
    }
      
    function getCategoryGraph($conditions) {
         //OTO category Count clicks
        $this->loadModel('OtoCategories');      
        $this->loadModel('UserProfiles');   
        $oto_categories =array();
        $oto_categories = $this->OtoCategories->find('all')
                                    ->contain([
                                          'UserProfiles' => [
                                                'queryBuilder' => function ($q) use ($conditions) {
                                            if (isset($conditions['user_id'])) {
                                              $q->where(['UserProfiles.user_id =' =>$conditions['user_id']]);
                                            }
                                            if (isset($conditions['doctor_id'])) {
                                              $q->where(['UserProfiles.doctor_id =' =>$conditions['doctor_id']]);
                                            }
                                            if (isset($conditions['start_at'])) {
                                              $q->where(['UserProfiles.start_at >=' =>$conditions['start_at']]);
                                            }
                                            if (isset($conditions['end_at'])) {
                                              $q->where(['UserProfiles.end_at <=' =>$conditions['end_at']]);
                                            }
                                            return $q;
                                          }]
                                        ])
                                    ->hydrate(false)
                                    ->toArray();
        
        $count_clicks =array();
        if(!empty($oto_categories)){
            $category_total = 0;
            foreach($oto_categories as $value){
                $count_clicks['name'][]=  $value['name']. ' '.count($value['user_profiles']);       
                $count_clicks['total'][]= count($value['user_profiles']);   
                $category_total += count($value['user_profiles']);  
            }
            $category_name = '"'.implode('"," ', $count_clicks['name']).'"';
            $category_count = implode(', ', $count_clicks['total']);       
        }       
         $this->set(compact('category_name','category_count','oto_categories','category_total'));       
    }

     function getRdiGraph($conditions) {
        //RDI PDF clicks
        $this->loadModel('PdfPages');
        // for only first RDI PDF
        $pdf_pages = array();
        $pdf_pages = $this->PdfPages->find('all')
                                ->where(['PdfPages.pdf_id =' => RDI_PDF_ID])                                            
                                ->contain([
                                      'PdfPageClicks' => [
                                            'queryBuilder' => function ($q) use ($conditions) {
                                        if (isset($conditions['user_id'])) {
                                          $q->where(['PdfPageClicks.user_id =' =>$conditions['user_id']]);
                                        }
                                        if (isset($conditions['doctor_id'])) {
                                          $q->where(['PdfPageClicks.doctor_id =' =>$conditions['doctor_id']]);
                                        }
                                        if (isset($conditions['start_at'])) {
                                          $q->where(['PdfPageClicks.start_at >=' =>$conditions['start_at']]);
                                        }
                                        if (isset($conditions['end_at'])) {
                                          $q->where(['PdfPageClicks.end_at <=' =>$conditions['end_at']]);
                                        }
                                        $q->where(['PdfPageClicks.pdf_id =' => RDI_PDF_ID]);
                                        return $q;
                                      }]
                                    ])
                                ->hydrate(false)
                                ->toArray();

        if(!empty($pdf_pages)){
            $page_total = 0;
            $page_clicks = array();
            foreach($pdf_pages as $key => $value){
                if(count($value['pdf_page_clicks']) != 0) {
                    $page_clicks['page_no'][]=  $value['page_no'];              
                    $page_clicks['total'][]= count($value['pdf_page_clicks']);         
                    $page_total += count($value['pdf_page_clicks']);           
                }else{
                    unset($page_clicks[$key]);
                    unset($pdf_pages[$key]);
                }      
            }
            if(!empty($page_clicks)){
                $page_name = '"Page '. implode(' ","Page ', $page_clicks['page_no']).'"'; 
                $page_count = implode(', ', $page_clicks['total']);
                $this->set(compact('page_name','page_count','pdf_pages','page_total'));
            } 
        }   
    }

    function getPackshotGraph($conditions) {
        //Packshot 1 pdf's
        $this->loadModel('Pdfs');       
        $this->loadModel('PdfPageClicks');      
        $pdfs = $this->Pdfs->find('all')
                            ->where(['Pdfs.is_packshot =' => PACKSHOT]) 
                            ->select(['Pdfs.id','Pdfs.name','Pdfs.is_packshot'])                                
                            ->hydrate(false)                                    
                            ->toArray();        
    
        $pageClicks = $this->PdfPageClicks->find('all')
                                    ->select(['PdfPageClicks.page_id'])
                                    ->group(['PdfPageClicks.page_id'])
                                    ->hydrate(false)                                    
                                    ->toArray();
        if(!empty($pageClicks)){
            $pdf_clicks = $packshot = array();
            $pdf_sum = 0;
            foreach($pageClicks as $key => $value){
                $total = 0;
                foreach($pdfs as $pdf){
                    
                    $search_conditions = array();   
                    $search_conditions['PdfPageClicks.pdf_id ='] = $pdf['id'];
                    $search_conditions['PdfPageClicks.page_id ='] = $value['page_id'];
                                
                    if (isset($conditions['user_id'])) {
                      $search_conditions['PdfPageClicks.user_id ='] = $conditions['user_id'];
                    }
                    if (isset($conditions['doctor_id'])) {
                     $search_conditions['PdfPageClicks.doctor_id ='] = $conditions['doctor_id'];
                    }
                    if (isset($conditions['start_at'])) {
                     $search_conditions['PdfPageClicks.start_at >='] = $conditions['start_at'];
                    }
                    if (isset($conditions['end_at'])) {
                      $search_conditions['PdfPageClicks.end_at <='] = $conditions['end_at'];
                    }
                    
                    $pdfClicks = $this->PdfPageClicks->find('all')
                                    ->select(['PdfPageClicks.id'])
                                    ->where($search_conditions)
                                    ->hydrate(false)                                    
                                    ->toArray();
                    $total += count($pdfClicks);
                }
                
                if($total>0){
                    $pdf_clicks['pdf_total'][] = 'Page'. $value['page_id'];
                    $packshot[] = 'Page'. $value['page_id'].' '.$total;
                
                }else{
                    unset($pdf_clicks['pdf_total'][$key]);
                    unset($packshot[$key]);
                }
                
                $pdf_clicks['total'][] = $total;
                $pdf_sum += $total;
            }
            if(!empty($pdf_clicks)){
                $pdf_count =(isset($pdf_clicks['total'])?implode(' , ', $pdf_clicks['total']):''); 
                $pdf_total = (isset($pdf_clicks['pdf_total'])?'"'.implode('","', $pdf_clicks['pdf_total']).'"':'');             
                $this->set(compact('pdf_count','pdf_total','pdf_sum','packshot'));
            }  
        }
    }
    
    public function getPackshotData()
    {
        $this->autoRender = false;
    
        if($this->request->is(['patch', 'post', 'put'])) {
            $conditions = $this->request->getData();
            $this->loadModel('PdfPageClicks');      
        
            $search_conditions = $pdfs = array();   
            if (isset($conditions['page_name']) && !empty($conditions['page_name'])) {
               $page_id = explode("Page", $conditions['page_name']);
               $search_conditions['PdfPageClicks.page_id ='] = $page_id[1];
            }           
            
            if (isset($conditions['user_id']) && !empty($conditions['user_id'])) {
              $search_conditions['PdfPageClicks.user_id ='] = $conditions['user_id'];
            }
            if (isset($conditions['doctor_id']) && !empty($conditions['doctor_id'])) {
             $search_conditions['PdfPageClicks.doctor_id ='] = $conditions['doctor_id'];
            }
            if (isset($conditions['start_at']) && !empty($conditions['start_at'])) {
             $search_conditions['PdfPageClicks.start_at >='] = $conditions['start_at'];
            }
            if (isset($conditions['end_at']) && !empty($conditions['end_at'])) {
              $search_conditions['PdfPageClicks.end_at <='] = $conditions['end_at'];
            }
            $pdfs = $this->PdfPageClicks->find('all')
                             ->where($search_conditions)
                             ->select([ 'PdfPageClicks.pdf_id','PdfPageClicks.page_id','Pdfs.id','Pdfs.name','Pdfs.is_packshot','totalRecords' => 'count(*)'])
                             ->contain(['Pdfs' => [
                                                'queryBuilder' => function ($q) {
                                                    $q->where(['Pdfs.is_packshot =' => PACKSHOT]);                                          
                                                return $q;
                                          }]
                                        ])
                            ->hydrate(false)
                            ->group(['PdfPageClicks.pdf_id'])                                   
                            ->toArray();
            if(!empty($pdfs)){
                foreach($pdfs as $key =>$pdf){
                    $lineDetails =array();
                    if(isset($pdf['pdf']) && count($pdf)>0){
                        $lineDe[$pdf['pdf']['name']]=$pdf['totalRecords'];              
                    }else{
                        unset($lineDetails[$key]);
                    }     
                }       
            }
             echo json_encode($lineDe);
             exit;
            }    
        }

    public function getRiskGraph($conditions) {
        $this->loadModel('Risks');      
            
        $risks = $this->Risks->find('all')
                             ->select(['Risks.id','Risks.risk_type'])
                             ->contain([
                                              'UserProfiles' => [
                                                    'queryBuilder' => function ($q) use ($conditions) {
                                                if (isset($conditions['user_id'])) {
                                                  $q->where(['UserProfiles.user_id =' =>$conditions['user_id']]);
                                                }
                                                if (isset($conditions['doctor_id'])) {
                                                  $q->where(['UserProfiles.doctor_id =' =>$conditions['doctor_id']]);
                                                }
                                                if (isset($conditions['start_at'])) {
                                                  $q->where(['UserProfiles.start_at >=' =>$conditions['start_at']]);
                                                }
                                                if (isset($conditions['end_at'])) {
                                                  $q->where(['UserProfiles.end_at <=' =>$conditions['end_at']]);
                                                }
                                                return $q;
                                              }]
                                            ])
                              ->hydrate(false)
                              ->toArray();
        if(!empty($risks)){
            $risk_total = 0;
            foreach($risks as $value){
                $risk_data['type'][] = $value['risk_type'];
                $risk_data['count'][] = count($value['user_profiles']);
                $risk_total += count($value['user_profiles']);
            }
            $risk_name = '"'.   implode(' ","', $risk_data['type']).'"'; 
            $risk_count =   implode(',', $risk_data['count']); 
            
            $this->set(compact('risk_name','risk_count','risk_total'));
    
             
        }   
    }

    public function getRiskData()
    {
        $this->autoRender = false;
        if($this->request->is(['patch', 'post', 'put'])) {
            $data = [];
            $conditions = $this->request->getData();
            if(!empty($conditions)){
              
            
            $this->loadModel('Risks');      
            $this->loadModel('UserProfiles');       
            $risks = $this->Risks->find()
                                 ->select(['Risks.id','Risks.risk_type'])
                                 ->where(['Risks.risk_type LIKE' => '%'.$conditions['risk_name'].'%'])
                                 ->hydrate(false)
                                 ->toArray();
                                
            $output = array();
            $output['RiskName'] = $risks[0]['risk_type'];
            $search_conditions = array();   
            $search_conditions['UserProfiles.risk_id'] = $risks[0]['id'];
                        
            if (isset($conditions['user_id']) && !empty($conditions['user_id'])) {
              $search_conditions['UserProfiles.user_id ='] = (int)$conditions['user_id'];
            }
            if (isset($conditions['doctor_id']) && !empty($conditions['doctor_id'])) {
             $search_conditions['UserProfiles.doctor_id ='] = (int)$conditions['doctor_id'];
            }
            if (isset($conditions['start_at']) && !empty($conditions['start_at'])) {
             $search_conditions['UserProfiles.start_at >='] = $conditions['start_at'];
            }
            if (isset($conditions['end_at']) && !empty($conditions['end_at'])) {
              $search_conditions['UserProfiles.end_at <='] = $conditions['end_at'];
            }
            //Risk details
            $riskDetails = $this->UserProfiles->find('all')
                                 ->where($search_conditions)
                                 ->contain(['RiskCategories','RiskSubCategories'])
                                 ->hydrate(false)
                                 ->toArray();
                                 
            foreach($riskDetails as $value){
                $riskDetail['id'] = $value['risk_sub_category']['id'];
                $riskDetail['name'] = $value['risk_sub_category']['name'];
                $riskDetail['cat_id'] = $value['risk_category']['id'];
                $riskDetail['cat_name'] = $value['risk_category']['name'];
                $categoryData[] = $riskDetail;
            }
            $result = array();
            //Group by Category name
            foreach ($categoryData as $data) {
                $id = $data['cat_name'];
                if (isset($result[$id])) {
                    $result[$id][] = $data;
                } else {                
                    $result[$id] = array($data);
                }
            }
            //Subcategory
            foreach($result as $key=>$val){             
                $cat['CategoryName'] =  $key."count - ".count($val);           
                $cat['SubCategory'] = array_count_values(array_column($val, 'name'));
                $output['CatDetail'][]= $cat;
            }
            echo json_encode($output);
            exit;
            }
        }
    }
}

<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Doctors Controller
 *
 * @property \App\Model\Table\DoctorsTable $Doctors
 */
class DoctorsController extends AppController
{
    public function initialize(){
        parent::initialize();
        $this->viewBuilder()->setLayout('admin');
    } 
    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $doctors = $this->paginate($this->Doctors);

        $this->set(compact('doctors'));
        $this->set('_serialize', ['doctors']);
    }

    /**
     * View method
     *
     * @param string|null $id Doctor id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $doctor = $this->Doctors->get($id, [
            'contain' => []
        ]);
        $doctor['region_name'] = $this->Common->fetchName('Regions', $doctor->region_id, 'name');
        $doctor['suburb_name'] = $this->Common->fetchName('Suburbs', $doctor->suburb_id, 'name');
        $doctor['practice_name'] = $this->Common->fetchName('Practices', $doctor->practice_id, 'name');
        $this->set('doctor', $doctor);
        $this->set('_serialize', ['doctor']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->loadModel('Practices');
        $doctor = $this->Doctors->newEntity();        
        if ($this->request->is('post')) {
			$region_id = $this->request->getData('region_id');
			$suburb_id = $this->request->getData('suburb_id');
			$practice_id = $this->request->getData('practice_id');
			$doctors = $this->Doctors->find('all')->select(['id'])->where(['region_id' => $region_id,'suburb_id'=> $suburb_id,'practice_id' => $practice_id,'first_name LIKE' => $this->request->getData('first_name')])->toArray();
			if(!empty($doctors)){
				$this->Flash->error(__('This name already exists for this region and suburb and practice'));
				return $this->redirect(['action' => 'add']);
			}else{
				$this->request->data['created_at'] = $this->request->data['updated_at'] = date("Y-m-d H:i:s");          
				$doctor = $this->Doctors->patchEntity($doctor, $this->request->getData());
				if ($this->Doctors->save($doctor)) {
					$this->Flash->success(__('The doctor has been saved.'));
					return $this->redirect(['action' => 'index']);
				}else{	
					$this->Flash->error(__('The doctor could not be saved. Please, try again.'));
				}
			}
        }
        $regions = $this->Doctors->Regions->find('list', ['limit' => 200]);
        $regionId = $this->Doctors->Regions->find('all')->select('id')->where(['id' => $this->request->data('region_id')])->first();
        $suburbs = $practices = [];
        if ($this->request->data) {
            $suburbs = $this->Doctors->Suburbs->find('all')->select('name','id')->where(['id ' => $regionId])->toArray(); 
            $suburbId = $this->Doctors->Suburbs->find('all')->select('id')->where(['id' => $this->request->data('suburb_id')])->first(); 
        }
        if ($this->request->data) {
            $practices = $this->Doctors->Practices->find('all')->select('name','id')->where(['id ' => $suburbId])->toArray();  
        }
        $this->set(compact('doctor','suburbs','practices','regions'));
        $this->set('_serialize', ['doctor']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Doctor id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {    
        $doctor = $this->Doctors->get($id, [
            'contain' => ['Regions','Suburbs','Practices']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
			$region_id = $this->request->getData('region_id');
			$suburb_id = $this->request->getData('suburb_id');
			$practice_id = $this->request->getData('practice_id');
			$doctors = $this->Doctors->find('all')->select(['id'])->where(['region_id' => $region_id,'suburb_id'=> $suburb_id,'practice_id' => $practice_id,'first_name LIKE' => $this->request->getData('first_name')])->toArray();
			if(!empty($doctors)){
				$this->Flash->error(__('This name already exists for this region and suburb and practice'));
				return $this->redirect(['action' => 'edit/'.$id]);
			}else{
				$this->request->data['updated_at'] = date("Y-m-d H:i:s");            
				$doctor = $this->Doctors->patchEntity($doctor, $this->request->getData());
				if ($this->Doctors->save($doctor)) {
					$this->Flash->success(__('The doctor has been saved.'));
					return $this->redirect(['action' => 'index']);
				}else{
					$this->Flash->error(__('The doctor could not be saved. Please, try again.')); 
				}
			}
        }
        $regions = $this->Doctors->Regions->find('list', ['limit' => 200]);
        $suburbs = $practices = [];
        if ($doctor['region_id']) {
            $suburbs = $this->Doctors->Suburbs->find('list',[
                            'keyField' => 'id',
                            'valueField' => 'name'])->where(['region_id ' => $doctor['region_id']]); 
        }
        if ($doctor['suburb_id']) {
            $practices = $this->Doctors->Practices->find('list',[
                            'keyField' => 'id',
                            'valueField' => 'name'])->where(['suburb_id ' => $doctor['suburb_id']]); 
        }
        $this->set(compact('doctor','regions','suburbs','practices'));
        $this->set('_serialize', ['doctor']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Doctor id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
		$doctors = $this->Doctors->find('all')->select(['first_name'])->where(['id' => $id])->first();
		$this->loadModel('SelectedExperts');
		$report = $this->SelectedExperts->find('all')->select(['id'])->where(['doctor_id' => $id])->first();
		$this->loadModel('UsersDoctors');
		$user = $this->UsersDoctors->find('all')->select(['id'])->where(['doctor_id' => $id])->hydrate(false)->toArray();
		if($report['id'] == '' && empty($user)){
			$doctor = $this->Doctors->get($id);
			if ($this->Doctors->delete($doctor)) {
				$this->Flash->success(__('The doctor has been deleted.'));
			} else {
				$this->Flash->error(__('The doctor could not be deleted. Please, try again.'));
			}
		}elseif(!empty($user)){
			$this->Flash->error(__('In Order to delete User ('.$doctors['first_name'].'), Please delete association with User.'));
		}else{
			$this->Flash->error(__('In Order to delete User ('.$doctors['first_name'].'), Please delete associated Report.'));
		}
		return $this->redirect(['action' => 'index']);
    }
    
    public function getDoctorSuburbByRegion(){
        $this->autoRender = false;
        $clients = [];
        $count = 0;
        if ($this->request->is(['patch', 'post', 'put']) ) {
            $this->loadModel('Regions');
            $this->loadModel('Suburbs');
            $regionId = $this->Regions->find('all')->select('id')->where(['name LIKE' => "%".$this->request->getData('region_id')."%"])->first();
            $suburbs = $this->Suburbs->find('all')->where(['region_id ' => $regionId['id']]); 
            $count = $suburbs->count();
            $suburbs = $suburbs->toArray();
        }
        $resultJson = json_encode(compact('suburbs','count'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response; 
    }
    
    public function getDoctorPracticeBySuburb(){
        $this->autoRender = false;
        $clients = [];
        $count = 0;
        if ($this->request->is(['patch', 'post', 'put']) ) {
            $this->loadModel('Practices');
            $this->loadModel('Suburbs');
            $suburbId = $this->Suburbs->find('all')->select('id')->where(['name LIKE' => "%".$this->request->getData('suburb_id')."%"])->first();
            $practices = $this->Practices->find('all')->where(['suburb_id ' => $suburbId['id']]); 
            $count = $practices->count();
            $suburbs = $practices->toArray();
        }
        $resultJson = json_encode(compact('practices','count'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response; 
    }
    
    public function toggleStatus()
    {
        $this->autoRender = false;
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = [];
            $status = $this->request->getData('status');
            foreach ($this->request->getData('ids') as $user_id) {
                $data[] = ['is_deleted' => $status, 'id' => $user_id];
            }
            $doctors = $this->Doctors->find()->where(['id in' => $this->request->getData('ids')]);
            $this->Doctors->patchEntities($doctors, $data);
            if ($this->Doctors->saveMany($doctors)) {
                echo DONE;
            } else {
                echo NOT_DONE;
            }
        }
    }
    /**
   * Show method
   *
   * @return \Cake\Network\Response|null
   */
    public function show()
    {
        $limit = ADMIN_PAGINATION_LIMIT;
        $offset = ($this->request->query(START)) ? $this->request->query(START) : 0;
        $conditions = $order = [];
        if ($this->request->query('order') && $this->request->query('order.0')) 
        {
            switch ($this->request->query('order.0.column')) {
                case 0:
                $order = ['Doctors.first_name ' . $this->request->query('order.0.dir')];
                break;
                case 1:
                $order = ['Doctors.last_name ' . $this->request->query('order.0.dir')];
                break;
                case 2:
                $order = ['Doctors.region_id ' . $this->request->query('order.0.dir')];
                break;
                case 3:
                $order = ['Doctors.suburb_id ' . $this->request->query('order.0.dir')];
                break;
                case 4:
                $order = ['Doctors.practice_id ' . $this->request->query('order.0.dir')];
                break;
                default:
                $order = ['Doctors.id DESC'];
                break;
            }
        }
        else {
          $order = ['Doctors.id DESC'];
        }
        if ($this->request->query('search.value')) {
            $conditions['or'][] = ['Doctors.first_name LIKE' => '%' . $this->request->query('search.value') . '%'];
            $conditions['or'][] = ['Doctors.last_name LIKE' => '%' . $this->request->query('search.value') . '%'];
            $conditions['or'][] = ['Doctors.Regions.name LIKE' => '%' . $this->request->query('search.value') . '%'];
            $conditions['or'][] = ['Doctors.Suburbs.name LIKE' => '%' . $this->request->query('search.value') . '%'];
            $conditions['or'][] = ['Doctors.Practices.name LIKE' => '%' . $this->request->query('search.value') . '%'];
        }
        $totalDoctors = $this->Doctors->find('all', ['conditions' => $conditions]);

        $doctors = $this->Doctors->find('all', [
            'conditions' => $conditions,
            'offset' => $offset,
            'limit' => $limit,
            'order' => $order,
            'contain' =>array('Regions','Practices','Suburbs'),
        ]);

        $data = [];
        $draw = 0;
        $recordsTotal = $totalDoctors->count();
        $recordsFiltered = $doctors->count();
        foreach ($doctors as $doctor) {
            $record = [];
            $record[] = $doctor->first_name;
            $record[] = !empty($doctor->last_name)?$doctor->last_name:'-';
            $record[] = $this->Common->fetchName('Regions', $doctor->region_id, 'name');
            $record[] = $this->Common->fetchName('Suburbs', $doctor->suburb_id, 'name');
            $record[] = $this->Common->fetchName('Practices', $doctor->practice_id, 'name');
            $record[] = date('Y-m-d', strtotime($doctor->created_at));
            $record[] = '&nbsp;&nbsp;<a title="View" href="/Doctors/view/' . $doctor->id . '"><i class="fa fac-info"></i></a>&nbsp;&nbsp;<a title="Edit" href="/Doctors/edit/' . $doctor->id . '"><i class="fa fac-edit"></i></a>&nbsp;&nbsp;<a onclick="toggleStatus(\'/Doctors/toggleStatus\',\'' . $doctor->id . '\')" href="javascript:void(0)" title="' . (($doctor->is_deleted) ? 'Deactivate' : 'Activate') . '" ><i class="active_' . $doctor->id . ' fa fac-' . (($doctor->is_deleted) ? 'deactive' : 'active') . '-action"></i></a>&nbsp;&nbsp;<a title="Delete" href="/Doctors/delete/' . $doctor->id . '"><i class="fa fac-trash"></i></a>';
         
            $data[] = $record;
        }
        $resultJson = json_encode(compact('draw', 'data', 'recordsTotal', 'recordsFiltered', START, 'length'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
    }
}

<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
/**
 * Packshots Controller
 *
 * @property \App\Model\Table\PackshotsTable $Packshots
 */
class PackshotsController extends AppController
{
	
      public function initialize(){
            parent::initialize();
            $this->viewBuilder()->setLayout('admin');
            $this->loadComponent('Security');
            $this->loadComponent('Csrf');        
            $this->loadComponent('Cookie', ['expires' => '+10 days']);
            $actions = [
              'setOrder'
            ];
            if (in_array($this->request->params['action'], $actions)) {
              // for csrf
              $this->eventManager()->off($this->Csrf);

              // for security component
              $this->Security->config('unlockedActions', $actions);
            }
      } 
      
    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $packshots = $this->paginate($this->Packshots);

        $this->set(compact('packshots'));
        $this->set('_serialize', ['packshots']);
    }

    /**
     * View method
     *
     * @param string|null $id Packshot id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $packshot = $this->Packshots->get($id, [
            'contain' => []
        ]);
        $packshot['brand_name']  = $this->Common->fetchMenuName('Brands', $packshot->brand_id, 'brand_name'); 
        $packshot['aws_video']  = $this->Common->readVideo(AWS_BUCKET_DEV, PACKSHOT_BUCKET.DIRECTORY_SEPARATOR.'video'.DIRECTORY_SEPARATOR.$packshot->file_path);
        $packshot['aws_pdf']  = $this->Common->readVideo(AWS_BUCKET_DEV, PACKSHOT_BUCKET.DIRECTORY_SEPARATOR.'pdf'.DIRECTORY_SEPARATOR.$packshot->file_path);
        $this->set('packshot', $packshot);
        $this->set('_serialize', ['packshot']);
    }

     public function toggleStatus()
      {
        $this->autoRender = false;
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = [];
            $status = $this->request->getData('status');
            foreach ($this->request->getData('ids') as $user_id) {
                $data[] = ['is_deleted' => $status, 'packshot_id' => $user_id];
            }
            $packshots = $this->Packshots->find()->where(['packshot_id in' => $this->request->getData('ids')]);
            $this->Packshots->patchEntities($packshots, $data);
            if ($this->Packshots->saveMany($packshots)) {
                echo DONE;
            } else {
                echo NOT_DONE;
            }
        }
    }
      
    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->loadModel('Brands');
        $packshot = $this->Packshots->newEntity();
        if ($this->request->is('post')) {
            $query = $this->Packshots->find();
            $order = $query->select(['order_no' => $query->func()->max('order_no')])->where(['brand_id' => $this->request->data['brand_id']])->first(); 
            $this->request->data['order_no'] = ($order['order_no'])+1;
            $this->request->data['created_at'] = $this->request->data['created_at'] = date("Y-m-d H:i:s");          
            $this->request->data['updated_at'] = $this->request->data['updated_at'] = date("Y-m-d H:i:s");   
            $type = $this->request->data('file_type');
            $packshotFile = $this->Common->imageFileValues($this->request->getData('file_path'));
            if ($packshotFile[TEMP_NAME] == '') {
                unset($this->request->data['file_path']);
            } else {
                $this->request->data['file_path'] = $packshotFile['name'];
            }
            $arr_ext = [];
            $folder = '';
            if($type == 0){
                $arr_ext = array('pdf');
                $folder = 'packshotPdf';
            }else{
                $arr_ext = array('mp4','3gp','mov','m4v','3g2');
                $folder = 'packshotVideo';
            }
            $packshot = $this->Packshots->patchEntity($packshot, $this->request->getData());
            //set allowed extensions
            if(!empty($this->request->data['file_path']) && !in_array($packshotFile['ext'], $arr_ext))
            {
                $this->Flash->error(__(INVALID_FILE));
            } 
            else{                        
                if ($this->Packshots->save($packshot)) {
                    if ($packshotFile[TEMP_NAME] != '') {
                        try {
                            $this->Common->awsPackshotUpload($packshotFile[TEMP_NAME], $packshotFile['name'], $packshotFile['size'], $packshotFile['ext'], $folder,$type);
                            
                        } catch (Exception $ex) {
                            $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                        }
                    }
                    $this->Flash->success(__('The packshot has been saved.'));
                    return $this->redirect(['action' => 'index']);
                }else{
                    $this->Flash->error(__('The packshot could not be saved. Please, try again.'));
                }
            }
        }
        $this->set(compact('packshot'));
        $this->set('_serialize', ['packshot']);
        $this->set('brands',$this->Common->menuesFetchList('Brands', 'is_deleted', 0));
    }

    /**
     * Edit method
     *
     * @param string|null $id packshot id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $packshot = $this->Packshots->get($id, [
            'contain' => []
        ]); 
		$packshot['aws_video']  = $this->Common->readVideo(AWS_BUCKET_DEV, PACKSHOT_BUCKET.DIRECTORY_SEPARATOR.'video'.DIRECTORY_SEPARATOR.$packshot->file_path);
		$packshot['aws_pdf']  = $this->Common->readVideo(AWS_BUCKET_DEV, PACKSHOT_BUCKET.DIRECTORY_SEPARATOR.'pdf'.DIRECTORY_SEPARATOR.$packshot->file_path);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $this->request->data['updated_at'] = $this->request->data['updated_at'] = date("Y-m-d H:i:s"); 
            $type = $this->request->data('file_type');
            $packshotFile = $this->Common->imageFileValues($this->request->getData('file_path'));
            if ($packshotFile[TEMP_NAME] == '') {
                unset($this->request->data['file_path']);
            } else {
                $this->request->data['file_path'] = $packshotFile['name'];
            }
            $arr_ext = [];
            $folder = '';
            if($type == 0){
                $arr_ext = array('pdf');
                $folder = 'packshotPdf';
            }else{
                $arr_ext = array('mp4','3gp','mov','m4v','3g2','mts');
                $folder = 'packshotVideo';
            }
            $packshot = $this->Packshots->patchEntity($packshot, $this->request->getData());
            //set allowed extensions
            if(!empty($this->request->data['file_path']) && !in_array($packshotFile['ext'], $arr_ext))
            {
                $this->Flash->error(__(INVALID_FILE));
            }else{  
                $packshot = $this->Packshots->patchEntity($packshot, $this->request->getData());
                    if ($this->Packshots->save($packshot)) {
                        if ($packshotFile[TEMP_NAME] != '') {
                            try {
                                $this->Common->awsPackshotUpload($packshotFile[TEMP_NAME], $packshotFile['name'], $packshotFile['size'], $packshotFile['ext'], $folder,$type);
                            } catch (Exception $ex) {
                                $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                            }
                        }
                        $this->Flash->success(__('The packshot has been saved.'));
                        return $this->redirect(['action' => 'index']);
                    }else{
                        $this->Flash->error(__('The Packshot could not be saved. Please, try again.'));
                    }
                }
        }
        $this->set(compact('packshot'));
        $this->set('_serialize', ['packshot']);
        $this->set('brands',$this->Common->menuesFetchList('Brands', 'is_deleted', 0));
    }


    /**
     * Delete method
     *
     * @param string|null $id Packshot id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $packshot = $this->Packshots->get($id);
        if ($this->Packshots->delete($packshot)) {
            $this->Flash->success(__('The packshot has been deleted.'));
        } else {
            $this->Flash->error(__('The packshot could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
    
    
    public function setOrder()
    {
        $this->loadModel('Brands');
        $this->viewBuilder()->setLayout(ADMIN);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = [];
        foreach ($this->request->getData('packshot_id') as $order => $packshot_id) {
            $data[] = ['order_no' => $order+1, 'packshot_id' => $packshot_id];
        }
        $packshots = $this->paginate($this->Packshots);
        $this->Packshots->patchEntities($packshots, $data);
        if ($this->Packshots->saveMany($packshots)) {
            $this->Flash->success(__(PACKSHOT_ORDER));
            return $this->redirect(['action' => 'index']);
        }
        }
        $packshots = $this->paginate($this->Packshots, ['order' => ['order_no' => 'ASC']]);
        $brands = $this->Brands->find()->select(['brand_name'])->toArray();
        $this->set(compact('brands','packshots'));
    }
    
    public function getPackshotsByBrand(){   
        $this->autoRender = false;
        $packshots = [];
        $count = 0;
        if ($this->request->is(['patch', 'post', 'put']) ) {
            $this->loadModel('Brands');
                $brands = $this->Brands->find('all')->select('brand_id')->where(['brand_name LIKE' => "%".$this->request->getData('brand_id')."%"])->hydrate(false)->toArray();
                $this->loadModel('Packshots');  
                foreach($brands as $brandId){
                    $brand_id= $brandId['brand_id'];
                }       
                $packshots = $this->Packshots->find('all')->where(['brand_id ' => $brand_id])->order(['order_no' => 'ASC']);
                $count = $packshots->count();
                $packshots = $packshots->toArray();

        }
        $resultJson = json_encode(compact('packshots','count'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response; 
    }
    
   /**
   * Show method
   *
   * @return \Cake\Network\Response|null
   */
    public function show()
    {
        $limit = ADMIN_PAGINATION_LIMIT;
        $offset = ($this->request->query(START)) ? $this->request->query(START) : 0;
        $conditions = $order =[];

        if ($this->request->query('order') && $this->request->query('order.0')) {
        {
            switch ($this->request->query('order.0.column')) {
                case 0:
                $order = ['Packshots.name ' . $this->request->query('order.0.dir')];
                break;
            case 1:
                $order = ['Packshots.brand_id ' . $this->request->query('order.0.dir')];
                break;
            default:
                $order = ['Packshots.packshot_id DESC'];
                break;
            }
        }
        } else {
            $order = ['Packshots.brand_id ASC,Packshots.order_no ASC'];
        }
        if ($this->request->query('search.value')) {
            $conditions[] = ['Packshots.name LIKE' => '%' . $this->request->query('search.value') . '%'];
        }
    
        $totalPackshots = $this->Packshots->find('all', ['conditions' => $conditions]);
        $packshots = $this->Packshots->find('all', [
            'conditions' => $conditions,
            'offset' => $offset,
            'limit' => $limit,
            'order' => $order
            ]);
    
        $data = [];
        $draw = 0;
        $recordsTotal = $totalPackshots->count();
        $recordsFiltered = $packshots->count();
        foreach ($packshots as $packshot) {
        $record = [];
        $record[] = $packshot->name;
        $record[] = $this->Common->fetchMenuName('Brands', $packshot->brand_id, 'brand_name');
        if($packshot->file_type == '0'){
            $type = 'PDF';
        }else{
            $type = 'Video';
        }
        $record[] = $type;
        $record[] = $packshot->order_no;
        $record[] = date('Y-m-d', strtotime($packshot->created_at));
        $record[] = '&nbsp;&nbsp;<a title="View" href="/Packshots/view/' . $packshot->packshot_id . '"><i class="fa fac-info"></i></a>&nbsp;&nbsp;<a title="Edit" href="/Packshots/edit/' . $packshot->packshot_id . '"><i class="fa fac-edit"></i></a>&nbsp;&nbsp;<a onclick="toggleStatus(\'/Packshots/toggleStatus\',\'' . $packshot->packshot_id . '\')" href="javascript:void(0)" title="' . (($packshot->is_deleted) ? 'Deactivate' : 'Activate') . '" ><i class="active_' . $packshot->packshot_id . ' fa fac-' . (($packshot->is_deleted) ? 'deactive' : 'active') . '-action"></i></a>';
        $data[] = $record;
        }
        $resultJson = json_encode(compact('draw', 'data', 'recordsTotal', 'recordsFiltered', START, 'length'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
    }
    
}

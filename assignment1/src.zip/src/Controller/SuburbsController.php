<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Suburbs Controller
 *
 * @property \App\Model\Table\SuburbsTable $Suburbs
 */
class SuburbsController extends AppController
{
    public function initialize(){
        parent::initialize();
        $this->viewBuilder()->setLayout('admin');
    } 
    

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $suburbs = $this->paginate($this->Suburbs);
        $this->set(compact('suburbs'));
        $this->set('_serialize', ['suburbs']);
    }

    /**
     * View method
     *
     * @param string|null $id Suburb id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $suburb = $this->Suburbs->get($id, [
            'contain' => []
        ]);
        $suburb['region_name'] = $this->Common->fetchName('Regions', $suburb->region_id, 'name');
        $this->set('suburb',  $suburb);
        $this->set('_serialize', ['suburb']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->loadModel('Regions');
        $suburb = $this->Suburbs->newEntity();
        if ($this->request->is('post')) {
			$region_id =  $this->request->getData('region_id');
			$regions = $this->Suburbs->find('all')->select(['id'])->where(['region_id' => $region_id,'name LIKE' => $this->request->getData('name')])->toArray();
			if (!empty($regions))
			{
				$this->Flash->error(__('This name already exists for this region'));
			}
			else
			{
				$this->request->data['created_at'] = $this->request->data['updated_at'] = date("Y-m-d H:i:s");           
				$suburb = $this->Suburbs->patchEntity($suburb, $this->request->getData());
				if ($this->Suburbs->save($suburb)) {
					$this->Flash->success(__('The suburb has been saved.'));
					return $this->redirect(['action' => 'index']);
				}else{
					$this->Flash->error(__('The suburb could not be saved. Please, try again.'));
				}
            }
        }
        $this->set(compact('suburb'));
        $this->set('_serialize', ['suburb']);        
        $this->set('regions',$this->Common->fetchList('Regions', 'is_deleted', 0));
    }

    /**
     * Edit method
     *
     * @param string|null $id Suburb id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $this->loadModel('Regions');
       
        $suburb = $this->Suburbs->get($id, [
            'contain' => []
        ]);
          $this->set('suburb_name',$suburb->name);
        if ($this->request->is(['patch', 'post', 'put'])) {
			$region_id =  $this->request->getData('region_id');
			$regions = $this->Suburbs->find('all')->select(['name'])->where(['region_id' => $region_id])->toArray();
			$name = [];
			foreach($regions as $region){
				$name[] = $region['name'];
			}
			if (in_array($this->request->getData('name'), $name))
			{
				$this->Flash->error(__('This name already exists for this region'));
			}else{
				$this->request->data['updated_at'] = date("Y-m-d H:i:s");            
				$suburb = $this->Suburbs->patchEntity($suburb, $this->request->getData());
				if ($this->Suburbs->save($suburb)) {
					$this->Flash->success(__('The suburb has been saved.'));
					return $this->redirect(['action' => 'index']);
				}else{
					$this->Flash->error(__('The suburb could not be saved. Please, try again.'));
				}
			}
        }
        $this->set(compact('suburb'));
        $this->set('_serialize', ['suburb']);
        $this->set('regions',$this->Common->fetchList('Regions', 'is_deleted', 0));
    }

    /**
     * Delete method
     *
     * @param string|null $id Region id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
		$suburbs = $this->Suburbs->find('all')->select(['name'])->where(['id' => $id])->first();
		$this->loadModel('Practices');
		$practice = $this->Practices->find('all')->select(['id'])->where(['suburb_id' => $id])->first();
		$this->loadModel('Doctors');
		$doctor = $this->Doctors->find('all')->select(['id'])->where(['suburb_id' => $id])->first();
		$this->loadModel('SelectedExperts');
		$report = $this->SelectedExperts->find('all')->select(['id'])->where(['suburb_id' => $id])->first();
		if($practice['id'] == '' && $doctor['id'] == '' && $report['id'] == ''){
			$suburb = $this->Suburbs->get($id);
			if ($this->Suburbs->delete($suburb)) {
				$this->Flash->success(__('The suburb '.$suburbs['name'].' has been deleted.'));
			} else {
				$this->Flash->error(__('The suburb could not be deleted. Please, try again.'));
			}
		}elseif($report['id'] != ''){
			$this->Flash->error(__('In Order to delete User ('.$suburbs['name'].'), Please delete associated Report.'));
		}else{
			$this->Flash->error(__('In Order to delete Suburb ('.$suburbs['name'].'), Please delete associated Relation with Practices or Doctors.'));
		}
		return $this->redirect(['action' => 'index']);
		
    }
    
    public function toggleStatus()
        {
        $this->autoRender = false;
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = [];
            $status = $this->request->getData('status');
            foreach ($this->request->getData('ids') as $suburb_id) {
                $data[] = ['is_deleted' => $status, 'id' => $suburb_id];
            }
            $Suburbs = $this->Suburbs->find()->where(['id in' => $this->request->getData('ids')]);
            $this->Suburbs->patchEntities($Suburbs, $data);
            if ($this->Suburbs->saveMany($Suburbs)) {
                echo DONE;
            } else {
                echo NOT_DONE;
            }
        }
    }
    /**
   * Show method
   *
   * @return \Cake\Network\Response|null
   */
   public function show()
   {
        $limit = ADMIN_PAGINATION_LIMIT;
        $offset = ($this->request->query(START)) ? $this->request->query(START) : 0;
        $conditions = $order = [];
        if ($this->request->query('order') && $this->request->query('order.0')) 
        {
            switch ($this->request->query('order.0.column')) {
                case 0:
                $order = ['Suburbs.name ' . $this->request->query('order.0.dir')];
                break;
                case 1:
                $order = ['Suburbs.region_id ' . $this->request->query('order.0.dir')];
                break;
                default:
                $order = ['Suburbs.id DESC'];
                break;
            }
        }
        else {
            $order = ['Suburbs.id DESC'];
        }
        if ($this->request->query('search.value')) {
            $conditions['or'][] = ['Suburbs.name LIKE' => '%' . $this->request->query('search.value') . '%'];
        }
        $totalSuburbs = $this->Suburbs->find('all', ['conditions' => $conditions]);

        $suburbs = $this->Suburbs->find('all', [
          'conditions' => $conditions,
          'offset' => $offset,
          'limit' => $limit,
          'order' => $order,
        ]);
    
        $data = [];
        $draw = 0;
        $recordsTotal = $totalSuburbs->count();
        $recordsFiltered = $suburbs->count();
          
        foreach ($suburbs as $suburb) {
            $record = [];
            $record[] = $suburb->name;
            $record[] = $this->Common->fetchName('Regions', $suburb->region_id, 'name');
            $record[] = date('Y-m-d', strtotime($suburb->created_at));
            $record[] = '&nbsp;&nbsp;<a title="View" href="/Suburbs/view/' . $suburb->id . '"><i class="fa fac-info"></i></a>&nbsp;&nbsp;<a title="Edit" href="/Suburbs/edit/' . $suburb->id . '"><i class="fa fac-edit"></i></a>&nbsp;&nbsp;<a onclick="toggleStatus(\'/Suburbs/toggleStatus\',\'' . $suburb->id . '\')" href="javascript:void(0)" title="' . (($suburb->is_deleted) ? 'Deactivate' : 'Activate') . '" ><i class="active_' . $suburb->id . ' fa fac-' . (($suburb->is_deleted) ? 'deactive' : 'active') . '-action"></i></a>&nbsp;&nbsp;<a title="Delete" href="/Suburbs/delete/' . $suburb->id . '"><i class="fa fac-trash"></i></a>';
         
            $data[] = $record;
        }
        $resultJson = json_encode(compact('draw', 'data', 'recordsTotal', 'recordsFiltered', START, 'length'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
    }
}


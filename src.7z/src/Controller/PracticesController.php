<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Practices Controller
 *
 * @property \App\Model\Table\PracticesTable $Practices
 */
class PracticesController extends AppController
{

    public function initialize(){
        parent::initialize();
        $this->viewBuilder()->setLayout('admin');
    } 
    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $practices = $this->paginate($this->Practices);

        $this->set(compact('practices'));
        $this->set('_serialize', ['practices']);
    }

    /**
     * View method
     *
     * @param string|null $id Practice id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $practice = $this->Practices->get($id, [
            'contain' => []
        ]);
        $practice['region_name'] = $this->Common->fetchName('Regions', $practice->region_id, 'name');
        $practice['suburb_name'] = $this->Common->fetchName('Suburbs', $practice->suburb_id, 'name');
        $this->set('practice', $practice);
        $this->set('_serialize', ['practice']);
    }
    
	
    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->loadModel('Suburbs');
        $practice = $this->Practices->newEntity();
        if ($this->request->is('post')) {
			$region_id = $this->request->getData('region_id');
			$suburb_id = $this->request->getData('suburb_id');
			$practices = $this->Practices->find('all')->select(['id'])->where(['region_id' => $region_id,'suburb_id'=> $suburb_id,'name LIKE' => $this->request->getData('name')])->toArray();
			if(!empty($practices)){
				$this->Flash->error(__('This name already exists for this region and suburb'));
				return $this->redirect(['action' => 'add']);
			}else{
				$this->request->data['created_at'] = $this->request->data['updated_at'] = date("Y-m-d H:i:s");           
				$practice = $this->Practices->patchEntity($practice, $this->request->getData());
				if ($this->Practices->save($practice)) {
					$this->Flash->success(__('The practice has been saved.'));
					return $this->redirect(['action' => 'index']);
				}else{
					$this->Flash->error(__('The practice could not be saved. Please, try again.'));
				}
			}			
        }
        $regions = $this->Practices->Regions->find('list', ['limit' => 200]);
        $regionId = $this->Practices->Regions->find('all')->select('id')->where(['id' => $this->request->data('region_id')])->first();
        $this->loadModel('Suburbs');
        $suburbs = [];
        if ($this->request->data) {
            $suburbs = $this->Suburbs->find('all')->select('name','id')->where(['id ' => $regionId])->toArray(); 
        }
        $this->set(compact('practice','regions','suburbs'));
        $this->set('_serialize', ['practice']);            
    }

    /**
     * Edit method
     *
     * @param string|null $id Practice id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $practice = $this->Practices->get($id, [
            'contain' => ['Suburbs','Regions']
        ]);
        $this->set('practice_name',$practice->name);
        if ($this->request->is(['patch', 'post', 'put'])) {
			$region_id = $this->request->getData('region_id');
			$suburb_id = $this->request->getData('suburb_id');
			$practices = $this->Practices->find('all')->select(['id'])->where(['region_id' => $region_id,'suburb_id'=> $suburb_id,'name LIKE' => $this->request->getData('name')])->toArray();
			if(!empty($practices)){
				$this->Flash->error(__('This name already exists for this region and suburb'));
				return $this->redirect(['action' => 'edit/'.$id]);
			}else{
				$this->request->data['updated_at'] = date("Y-m-d H:i:s");            
				$practice = $this->Practices->patchEntity($practice, $this->request->getData());
				if ($this->Practices->save($practice)) {
					$this->Flash->success(__('The practice has been saved.'));
					return $this->redirect(['action' => 'index']);
				}else{
					$this->Flash->error(__('The practice could not be saved. Please, try again.'));
				}
			}
        }
        $regions = $this->Practices->Regions->find('list', ['limit' => 200]);
        $suburbs = [];
         if ($practice['region_id']) {
            $suburbs = $this->Practices->Suburbs->find('list',[
                            'keyField' => 'id',
                            'valueField' => 'name'])->where(['region_id ' => $practice['region_id']]); 
        }
      
        $this->set(compact('practice','suburbs','regions'));
        $this->set('_serialize', ['practice']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Region id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
		$practices = $this->Practices->find('all')->select(['name'])->where(['id' => $id])->first();
		$this->loadModel('Doctors');
		$doctor = $this->Doctors->find('all')->select(['id'])->where(['practice_id' => $id])->first();
		$this->loadModel('SelectedExperts');
		$report = $this->SelectedExperts->find('all')->select(['id'])->where(['practice_id' => $id])->first();
		if($doctor['id'] == '' && $report['id'] == ''){
			$practice = $this->Practices->get($id);
			if ($this->Practices->delete($practice)) {
				$this->Flash->success(__('The Practice '.$practices['name'].' has been deleted.'));
			} else {
				$this->Flash->error(__('The practice could not be deleted. Please, try again.'));
			}
		}elseif($report['id'] != ''){
			$this->Flash->error(__('In Order to delete User ('.$practices['name'].'), Please delete associated Report.'));
		}else{
			$this->Flash->error(__('In Order to delete Practice ('.$practices['name'].'), Please delete associated Relation with Doctors.'));
		}
		return $this->redirect(['action' => 'index']);
		
    }
    
    public function getSuburbByRegion(){
        $this->autoRender = false;
        $clients = [];
        $count = 0;
        if ($this->request->is(['patch', 'post', 'put']) ) {
            $this->loadModel('Regions');
            $this->loadModel('Suburbs');
            $regionId = $this->Regions->find('all')->select('id')->where(['name LIKE' => "%".$this->request->getData('region_id')."%"])->first();
            $suburbs = $this->Suburbs->find('all')->where(['region_id ' => $regionId['id']]); 
            $count = $suburbs->count();
            $suburbs = $suburbs->toArray();
        }
        $resultJson = json_encode(compact('suburbs','count'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response; 
    }
    
    public function toggleStatus()
    {
        $this->autoRender = false;
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = [];
            $status = $this->request->getData('status');
            foreach ($this->request->getData('ids') as $suburb_id) {
                $data[] = ['is_deleted' => $status, 'id' => $suburb_id];
            }
            $Practices = $this->Practices->find()->where(['id in' => $this->request->getData('ids')]);
            $this->Practices->patchEntities($Practices, $data);
            if ($this->Practices->saveMany($Practices)) {
                echo DONE;
            } else {
                echo NOT_DONE;
            }
        }
    }
    /**
   * Show method
   *
   * @return \Cake\Network\Response|null
   */
    public function show()
    {
        $limit = ADMIN_PAGINATION_LIMIT;
        $offset = ($this->request->query(START)) ? $this->request->query(START) : 0;
        $conditions = $order =  [];
        if ($this->request->query('order') && $this->request->query('order.0')) 
        {
            switch ($this->request->query('order.0.column')) {
                case 0:
                    $order = ['Practices.name ' . $this->request->query('order.0.dir')];
                    break;
                case 1:
                    $order = ['Practices.suburb_id ' . $this->request->query('order.0.dir')];
                    break;
                case 2:
                    $order = ['Practices.region_id ' . $this->request->query('order.0.dir')];
                    break;
                default:
                    $order = ['Practices.id DESC'];
                    break;
            }
        }
        else {
            $order = ['Practices.id DESC'];
        }
        if ($this->request->query('search.value')) {
            $conditions[] = ['Practices.name LIKE' => '%' . $this->request->query('search.value') . '%'];
        }
        $totalPractices = $this->Practices->find('all', ['conditions' => $conditions]);

        $practices = $this->Practices->find('all', [
            'conditions' => $conditions,
            'offset' => $offset,
            'limit' => $limit,
            'order' => $order,

        ]);
    
        $data = [];
        $draw = 0;
        $recordsTotal = $totalPractices->count();
        $recordsFiltered = $practices->count();
        foreach ($practices as $practice) {
            $record = [];
            $record[] = $practice->name;
            $record[] = $this->Common->fetchName('Suburbs', $practice->suburb_id, 'name');
            $record[] = $this->Common->fetchName('Regions', $practice->region_id, 'name');
            $record[] = date('Y-m-d', strtotime($practice->created_at));
            $record[] = '&nbsp;&nbsp;<a title="View" href="/Practices/view/' . $practice->id . '"><i class="fa fac-info"></i></a>&nbsp;&nbsp;<a title="Edit" href="/Practices/edit/' . $practice->id . '"><i class="fa fac-edit"></i></a>&nbsp;&nbsp;<a onclick="toggleStatus(\'/Practices/toggleStatus\',\'' . $practice->id . '\')" href="javascript:void(0)" title="' . (($practice->is_deleted) ? 'Deactivate' : 'Activate') . '" ><i class="active_' . $practice->id . ' fa fac-' . (($practice->is_deleted) ? 'deactive' : 'active') . '-action"></i></a>&nbsp;&nbsp;<a title="Delete" href="/Practices/delete/' . $practice->id . '"><i class="fa fac-trash"></i></a>';
     
            $data[] = $record;
        }
        $resultJson = json_encode(compact('draw', 'data', 'recordsTotal', 'recordsFiltered', START, 'length'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;

    }
}

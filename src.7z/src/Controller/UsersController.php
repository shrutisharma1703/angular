<?php
namespace App\Controller;
use Cake\Mailer\Email;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class UsersController extends AppController
{
    public function initialize(){
        parent::initialize();
        $this->viewBuilder()->setLayout('admin');
        $this->Auth->allow('forgot');
    } 

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $users = $this->paginate($this->Users);
        $this->set(compact('users'));
        $this->set('_serialize', ['users']);  
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->loadModel('UsersBrands');
        $this->loadModel('UsersDoctors');
        $user = $this->Users->get($id, [
            'contain' => ['Brands','Doctors']
        ]);
        if(!empty($user['brands'])){
            //for brands
            $usersBrands = $this->UsersBrands->find()->where(['user_id' => $user->id])->toArray();
            $brand_id = array();
            if(!empty($usersBrands)){
                foreach($usersBrands as $usersBrand){
                    $brand_id[] = $usersBrand->brand_id;  
                }
                $brands = $this->Users->Brands->find()->select('brand_name')->where(['brand_id IN' => $brand_id])->toArray();
                $brandName = array();
                foreach($brands as $brand){  
                    $brandName[] = $brand->brand_name;
                }
                $name = implode(', ',$brandName);   
            }
            else{
                $name = '-';
            }
             $user['brand_name'] = $name;
        }
        $this->set(compact('user'));
        $this->set('_serialize', ['user']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $user = $this->Users->newEntity();    
        if ($this->request->is('post')) {
            $image = $this->Common->imageFileValues($this->request->getData('image_path'));
            if ($image[TEMP_NAME] == '') {
                unset($this->request->data['image_path']);
            } else {
                $this->request->data['image_path'] = $image['name'];
            }
            $this->request->data['created_date'] = date("Y-m-d H:i:s");         
            $this->request->data['modified_date'] = date("Y-m-d H:i:s");         
            $arr_ext = array('jpg', 'jpeg', 'gif', 'png', 'bmp');
            //set allowed extensions
            if(!empty($this->request->data['image_path']) && !in_array($image['ext'], $arr_ext))
            {
                $this->Flash->error(__(INVALID_FILE));
            }else{
                $user = $this->Users->patchEntity($user, $this->request->getData(), [
                    'associated' => ['Brands','Doctors']]);
                if ($this->Users->save($user)) {
                    if ($image[TEMP_NAME] != '') {
                        try {
                            $this->Common->imageFileUpload($image[TEMP_NAME], $image['name'], $image['size'], $image['ext'], 'users');
                        } catch (Exception $ex) {
                            $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                        }
                    }
                    $this->Flash->success(__(USER_SAVE));
                    return $this->redirect(['action' => 'index']);
                    } 
                    $this->Flash->error(__(USER_NOT_SAVED));
            }
        }
        $brands = $this->Users->Brands->find('list', [
        'valueField' => function ($row) {
            return $row['brand_name'];
        }])->toArray();
        $this->set(compact('user','brands','regions','suburbs','practices','doctors'));
        $this->set('_serialize', ['user','brands']);
    }

    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    { 
        $user = $this->Users->get($id, [
            'contain' => ['Brands']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {   
            if(!empty($this->request->getData('new_password'))){
                $this->request->data['password'] = $this->request->getData('new_password');
            }
           $this->request->data['modified_date'] = date("Y-m-d H:i:s");
            $image = $this->Common->imageFileValues($this->request->getData('image_path'));
            if ($image[TEMP_NAME] == '') {
                unset($this->request->data['image_path']);
            } else {
                $this->request->data['image_path'] = $image['name'];
            }
            $arr_ext = array('jpg', 'jpeg', 'gif', 'png', 'bmp');
            //set allowed extensions
            if(!empty($this->request->data['image_path']) && !in_array($image['ext'], $arr_ext))
            {
                $this->Flash->error(__(INVALID_FILE));
            }else{              
                $user = $this->Users->patchEntity($user, $this->request->getData());
                if ($this->Users->save($user)) {
                    if ($image[TEMP_NAME] != '') {
                        try {
                            $this->Common->imageFileUpload($image[TEMP_NAME], $image['name'], $image['size'], $image['ext'], 'users');
                        } catch (Exception $ex) {
                            $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                        }
                    }
                    $this->Flash->success(__(USER_SAVE));
                    return $this->redirect(['action' => 'index']);
                    } 
                    $this->Flash->error(__(USER_NOT_SAVED));  
            }        
        }
        $brands = $this->Users->Brands->find('list', [
        'valueField' => function ($row) {
            return $row['brand_name'];
        }])->toArray();
        $this->set(compact('user','brands','regions','suburbs','practices','doctors'));
        $this->set('_serialize', ['user']);
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $users = $this->Users->find('all')->select(['first_name'])->where(['id' => $id])->first();
        $this->loadModel('SelectedExperts');
        $report = $this->SelectedExperts->find('all')->select(['id'])->where(['user_id' => $id])->first();
        $this->loadModel('UsersDoctors');
        $this->loadModel('UsersBrands');
        if($report['id'] == ''){
            $user = $this->Users->get($id);
            if ($this->Users->delete($user)) {
                $this->UsersDoctors->deleteAll(['user_id IN' => $id]);
                $this->UsersBrands->deleteAll(['user_id IN' => $id]);
                $this->Flash->success(__('The user has been deleted.'));
            } else {
                $this->Flash->error(__('The user could not be deleted. Please, try again.'));
            }
        }else{
            $this->Flash->error(__('In Order to delete User ('.$users['first_name'].'), Please delete associated Report.'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    public function DoctorDelete($doctor_id = null,$user_id = null)
    {
        $this->loadModel('UsersDoctors');
        $user = $this->UsersDoctors->find()->select('id')->where(['doctor_id' => $doctor_id,'user_id' => $user_id])->first();
        if ($this->UsersDoctors->delete($user)) {
            $this->Flash->success(__('The user Doctor has been deleted.'));
        } else {
            $this->Flash->error(__('The user Doctor could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
    
    public function login()
    {
        //set layout
        $this->viewBuilder()->layout('login');
        //set title
        $this->set('title', 'Login');
        if ($this->request->is('post')) {
            
            $user = $this->Auth->identify();
            if ($user) {
                if($user['role'] == 0){
                    $this->Auth->setUser($user);
                    if ($this->request->data('remember_me')) {
                        $this->Cookie->write('Auth.User',
                            ['username' => $this->request->getData('username'), 'password' => $this->request->getData('password')]
                        );
                    }
                    return $this->redirect( $this->redirect(array("controller" => "Pages","action" => "home")));
                }else{
                    $this->Flash->error(__('Invalid access, try again'),array('class' => 'alert alert-danger'));
                }
            }
            $this->Flash->error(__('Invalid username or password, try again'),array('class' => 'alert alert-danger'));
         }        
     
    }
    public function forgot()
    {
        //set layout
        $this->viewBuilder()->layout('login');
        //set title
        $this->set('title', 'Forgot Password');
        
        if ($this->request->is('post')) {
            $sent = 0;
            $user = array();
            if(!empty($this->request->getData('email_username'))){
            //For Admin Role
                $user = $this->Users->find()->where(['username' => $this->request->getData('email_username'),'role ='=>0])->first();
                if (is_null($user)) {      
                    $user = $this->Users->find()->where(['email' => $this->request->getData('email_username'),'role ='=>0])->first();
                    if (is_null($user)) {
                        $this->Flash->error(__('Invalid Credentials, try again'));
                    }else{
                       $sent = 1;
                    }
                }else if(empty($user->email)){
                    $this->Flash->error(__(NO_EMAIL_EXIST_MESSAGE),array('class' => 'alert alert-danger'));
                } else {
                   $sent = 1;                
                }
              
                if($sent == 1){
                   
                    $password = $this->Common->generateRandomString(6);
                    $user = $this->Users->patchEntity($user, ['password' => $password]);
                    if ($this->Users->save($user)) {
                        //send email to user
                        $email = new Email('default');
                        $email->setSender([ADMIN_EMAIL => SITE_NAME])
                            ->setFrom([ADMIN_EMAIL => SITE_NAME])
                            ->setTo($user->email)
                            ->setSubject(PASSWORD_CHANGE_SUBJECT)
                            ->setEmailFormat('html')
                            ->setTemplate('forgot_password')
                            ->setViewVars(['user' => $user->toArray(), 'password' => $password])
                            ->send();
                    
                        $this->Flash->success(__('Password has been sent to email.'));

                    } else {
                        $this->Flash->error(__('Invalid Credentials, try again'));
                    }               
                }
            }else{
                    $this->Flash->error(__('Invalid Credentials, try again'));
                }
        }
    }
    
    public function settings($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {  
            if(!empty($this->request->getData('new_password'))){
                $this->request->data['password'] = $this->request->getData('new_password');
            }
            $this->request->data['modified_date'] = date("Y-m-d H:i:s");
            $image = $this->Common->imageFileValues($this->request->getData('image_path'));
            if ($image[TEMP_NAME] == '') {
                unset($this->request->data['image_path']);
            } else {
                $this->request->data['image_path'] = $image['name'];
            }
            $arr_ext = array('jpg', 'jpeg', 'gif', 'png', 'bmp');
            //set allowed extensions
            if(!empty($this->request->data['image_path']) && !in_array($image['ext'], $arr_ext))
            {
                $this->Flash->error(__(INVALID_FILE));
            }else{              
                $user = $this->Users->patchEntity($user, $this->request->getData());
                if ($this->Users->save($user)) {
                    if ($image[TEMP_NAME] != '') {
                        try {
                            $this->Common->imageFileUpload($image[TEMP_NAME], $image['name'], $image['size'], $image['ext'], 'users');
                        } catch (Exception $ex) {
                            $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                        }
                    }
                    $this->Flash->success(__('The Setting changes has been saved. Changes will be reflected in next Login. '));
                    return $this->redirect(['action' => 'settings/'.$id]);
                    } 
                    $this->Flash->error(__('Setting couldnot be saved. Please try again.'));
                }        
        }
        $this->set(compact('user'));
        $this->set('_serialize', ['user']);
    }
    
    public function logout()
    {
        return $this->redirect($this->Auth->logout());
    }
    
    public function linkDoctors($id)
    {
        $user = $this->Users->find('all')->select(['id','first_name'])->where(['id' => $id])->first();
        $this->set(compact('user'));
        $this->set('_serialize', ['user']);
    }
    
    public function toggleStatus()
    {
        $this->autoRender = false;
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = [];
            $status = $this->request->getData('status');
            foreach ($this->request->getData('ids') as $user_id) {
                $data[] = ['is_active' => $status, 'id' => $user_id];
            }
            $users = $this->Users->find()->where(['id in' => $this->request->getData('ids')]);
            $this->Users->patchEntities($users, $data);
            if ($this->Users->saveMany($users)) {
                echo DONE;
            } else {
                echo NOT_DONE;
            }
        }
    }
    
    /**
    * Show method
    *
    * @return \Cake\Network\Response|null
    */
    public function showDoctors($id)
    {
        $limit = DOCTOR_PAGINATION_LIMIT;
        $offset = ($this->request->query(START)) ? $this->request->query(START) : 0;
        $conditions = $order = [];
        $this->loadModel('Doctors');
        $this->loadModel('UsersDoctors');
        if ($this->request->query('order') && $this->request->query('order.0')) 
        {
            switch ($this->request->query('order.0.column')) {
                case 0:
                    $order = ['Doctors.first_name ' . $this->request->query('order.0.dir')];
                    break;
                default:
                    $order = ['Doctors.id DESC'];
                    break;
            }
        } else {
            $order = ['Doctors.id DESC'];
        }
        if ($this->request->query('search.value')) {
            $conditions[] = ['Doctors.first_name LIKE' => '%' . $this->request->query('search.value') . '%'];
        }
        
        $totalDoctors = $this->Doctors->find('all', ['conditions' => $conditions]);            
        $doctors = $this->Doctors->find('all', [
                                  'conditions' => $conditions,
                                  'offset' => $offset,
                                  'limit' => $limit,
                                  'order' => $order,
                                ]);
        
        $data = [];
        $draw = 0;
        $recordsTotal = $totalDoctors->count();
        $recordsFiltered = $doctors->count();
        $userDoctor = $this->UsersDoctors->find('list', ['valueField' => 'doctor_id'])->where(['user_id' => $id])->toArray();
        $userDoctor = array_values($userDoctor);
        foreach ($doctors as $doctor) {
            $record = [];
            if(in_array($doctor->id,$userDoctor)) {
                $record[] = '<input name="check_amb[]"  onclick="toggleAvailable(\'/users/toggleAvailable\',\'check_' . $doctor->id . '\','.$id.')" value="' . $doctor->id . '" checked="checked" id="check_' . $doctor->id . '" type="checkbox">';
            } else {
                $record[] = '<input name="check_amb[]" onclick="toggleAvailable(\'/users/toggleAvailable\',\'check_' . $doctor->id . '\','.$id.')" value="' . $doctor->id . '"  id="check_' . $doctor->id . '" type="checkbox">';
            }
            $record[] = $doctor->first_name;
            $record[] = $this->Common->fetchName('Regions', $doctor->region_id, 'name');;
            $record[] = $this->Common->fetchName('Suburbs', $doctor->suburb_id, 'name');;
            $record[] = $this->Common->fetchName('Practices', $doctor->practice_id, 'name');;
            if(in_array($doctor->id,$userDoctor)) {
                $record[] = '<i class="active_' . $doctor->id .' fa fac-active-action"></i>';
            } else {
                $record[] = '<i class="active_'. $doctor->id . ' fa fac-deactive-action"></i>';
            }
            $data[] = $record;
        }
        $resultJson = json_encode(compact('draw', 'data', 'recordsTotal', 'recordsFiltered', START, 'length'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;

    }
	
	public function viewDoctors($id)
    {
        $limit = DOCTOR_PAGINATION_LIMIT;
        $offset = ($this->request->query(START)) ? $this->request->query(START) : 0;
        $conditions = $order = [];
        $this->loadModel('Doctors');
        $this->loadModel('UsersDoctors');
        $UserDoctors = $this->UsersDoctors->find()->where(['user_id' => $id])->toArray();
		$doctor_id = array();
		if(!empty($UserDoctors)){
			foreach($UserDoctors as $UserDoctor){
				$doctor_id[] = $UserDoctor->doctor_id;  
			}
		}
		
		if ($this->request->query('order') && $this->request->query('order.0')) 
        {
            switch ($this->request->query('order.0.column')) {
                case 0:
                    $order = ['Doctors.first_name ' . $this->request->query('order.0.dir')];
                    break;
                case 1:
                    $order = ['Doctors.region_id ' . $this->request->query('order.0.dir')];
                    break;
                case 2:
                    $order = ['Doctors.suburb_id ' . $this->request->query('order.0.dir')];
                    break;
                case 3:
                    $order = ['Doctors.practice_id ' . $this->request->query('order.0.dir')];
                    break;
                default:
                    $order = ['Doctors.id DESC'];
                    break;
            }
        } else {
            $order = ['Doctors.id DESC'];
        }
        if ($this->request->query('search.value')) {
            $conditions[] = ['Doctors.first_name LIKE' => '%' . $this->request->query('search.value') . '%'];
        }
        
		$conditions[] = ['id IN'=>$doctor_id];
        $totalDoctors = $this->Doctors->find('all', ['conditions' => $conditions]);            
        $doctors = $this->Doctors->find('all', [
                                  'conditions' => $conditions,
                                  'offset' => $offset,
                                  'limit' => $limit,
                                  'order' => $order,
                                ]);
        
        $data = [];
        $draw = 0;
        $recordsTotal = $totalDoctors->count();
        $recordsFiltered = $doctors->count();
        foreach ($doctors as $doctor) {
            $record = [];
            $record[] = $doctor->first_name;
            $record[] = $this->Common->fetchName('Regions', $doctor->region_id, 'name');;
            $record[] = $this->Common->fetchName('Suburbs', $doctor->suburb_id, 'name');;
            $record[] = $this->Common->fetchName('Practices', $doctor->practice_id, 'name');;
            $data[] = $record;
        }
        $resultJson = json_encode(compact('draw', 'data', 'recordsTotal', 'recordsFiltered', START, 'length'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;

    }
    
    public function toggleAvailable()
    {
        $this->loadModel('UsersDoctors');
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = [];
            $status = $this->request->getData('status');
            $userId = $this->request->getData('id');
            $doctorId = $this->request->getData('doctorId'); 
            if($status == 'add') {
                $data = array(
                    'user_id' => $userId,
                    'doctor_id' => $doctorId,
                );
                $userDoctors = $this->UsersDoctors->newEntity();
                $userDoctors = $this->UsersDoctors->patchEntity($userDoctors, $data);
                if($this->UsersDoctors->save($userDoctors)) {
                    echo DONE;
                } else {
                    echo NOT_DONE;
                }
            }
            else {
                $userDoctors = $this->UsersDoctors->find()->select('id')->where(['doctor_id' => $doctorId])->where(['user_id' => $userId])->first();
                $userDoctorsEntity = $this->UsersDoctors->get($userDoctors->id);
                if($this->UsersDoctors->delete($userDoctorsEntity)) {
                    echo DONE;
                } else {
                    echo NOT_DONE;
                }   
            }
        }
        $this->autoRender = false;
    }
    /**
    * Show method
    *
    * @return \Cake\Network\Response|null
    */
    public function show()
    {
        $limit = ADMIN_PAGINATION_LIMIT;
        $offset = ($this->request->query(START)) ? $this->request->query(START) : 0;
        $conditions = $order = [];
        if ($this->request->query('order') && $this->request->query('order.0')) 
        {
            switch ($this->request->query('order.0.column')) {
                case 0:
                    $order = ['Users.first_name ' . $this->request->query('order.0.dir')];
                    break;
                case 1:
                    $order = ['Users.last_name ' . $this->request->query('order.0.dir')];
                    break;
                case 2:
                    $order = ['Users.username ' . $this->request->query('order.0.dir')];
                    break;
                case 3:
                    $order = ['Users.email ' . $this->request->query('order.0.dir')];
                    break;
                case 4:
                    $order = ['Users.title ' . $this->request->query('order.0.dir')];
                    break;
                case 5:
                    $order = ['Users.position ' . $this->request->query('order.0.dir')];
                    break;
                default:
                    $order = ['Users.id DESC'];
                    break;
            }
        
        } else {
            $order = ['Users.id DESC'];
        }
        if ($this->request->query('search.value')) {
            $conditions[] = ['Users.first_name LIKE' => '%' . $this->request->query('search.value') . '%'];
            $conditions[] = ['Users.username LIKE' => '%' . $this->request->query('search.value') . '%'];
        }
        
        $totalUsers = $this->Users->find('all', ['conditions' => $conditions])
                              ->where(['Users.id !='=>$this->request->session()->read('Auth.User.id')]);

        $users = $this->Users->find('all', [
                                  'conditions' => $conditions,
                                  'offset' => $offset,
                                  'limit' => $limit,
                                  'order' => $order,
                                ])->where(['Users.id !='=>$this->request->session()->read('Auth.User.id')]);
        $this->loadModel('UsersBrands');
        $this->loadModel('UsersDoctors');
        $this->loadModel('Doctors');
        $this->loadModel('Brands');
        $data = [];
        $draw = 0;
        $recordsTotal = $totalUsers->count();
        $recordsFiltered = $users->count();
        foreach ($users as $user) {
            $availableDoctor = $this->UsersDoctors->find('list', ['conditions' => ['user_id' => $user->id]])->count();
            $record = [];
            $record[] = $user->first_name.' '.$user->last_name;
            $record[] = $user->username;
            $record[] = $user->email;
            $usersBrands = $this->UsersBrands->find()->where(['user_id' => $user->id])->toArray();
            $brand_id = array();
            if(!empty($usersBrands)){
                foreach($usersBrands as $usersBrand){
                    $brand_id[] = $usersBrand->brand_id;  
                }
            $brands = $this->Brands->find()->select('brand_name')->where(['brand_id IN' => $brand_id])->toArray();
            $brandName = array();
            foreach($brands as $brand){  
                    $brandName[] = $brand->brand_name;
            }
            $name = implode(', ',$brandName);   
            }
            else{
                $name = '-';
            }
            $record[] = $name;
            $record[] = '<a title="Link" href="/Users/linkDoctors/' . $user->id . '">'.$availableDoctor.'</a>'; 
            $record[] = date('Y-m-d', strtotime($user->created_date));
            $record[] = '&nbsp;&nbsp;<a title="View" href="/users/view/' . $user->id . '"><i class="fa fac-info"></i></a>&nbsp;&nbsp;<a title="Edit" href="/users/edit/' . $user->id . '"><i class="fa fac-edit"></i></a>&nbsp;&nbsp;<a onclick="toggleStatus(\'/users/toggleStatus\',\'' . $user->id . '\')" href="javascript:void(0)" title="' . (($user->is_active) ? 'Deactivate' : 'Activate') . '" ><i class="active_' . $user->id . ' fa fac-' . (($user->is_active) ? 'deactive' : 'active') . '-action"></i></a>&nbsp;&nbsp;<a title="Delete" href="/Users/delete/' . $user->id . '"><i class="fa fac-trash"></i></a>&nbsp;&nbsp;<a title="Link" href="/Users/linkDoctors/' . $user->id . '"><i class="fa fac-link"></i></a>';
     
            $data[] = $record;
        }
        $resultJson = json_encode(compact('draw', 'data', 'recordsTotal', 'recordsFiltered', START, 'length'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;

    }
    
}

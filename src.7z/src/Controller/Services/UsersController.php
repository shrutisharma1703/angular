<?php
namespace App\Controller\Services;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Mailer\Email;

class UsersController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('Common');
    }
    /**
    * Before filter callback.
    *
    * @param \Cake\Event\Event $event The beforeRender event.
    * @return \Cake\Network\Response|null|void
    */
    public function beforeFilter(Event $event)
    {
        $json = [];
        $this->eventManager()->off($this->Csrf);
        $init_actions = ['login', 'forgotPassword', 'updatePassword'];
        $other_actions = ['getMasterData','getRiskData', 'saveExpert','logout','saveNewRiskClicks','saveRiskClicks','savePdfClicks','getBrands'];
        $unlock_actions = array_merge($init_actions, $other_actions);
        $this->Security->config('unlockedActions', $unlock_actions);
        if (in_array($this->request->action, $init_actions)) {
            
            if (is_null($this->request->env('HTTP_TOKEN'))) {
                $json = array(
                    'status' => HEADERTOKENFAILCODE,
                    'message' => HEADERTOKENMISSINGMESSAGE,
            );
            } else {
                $this->loadModel('RequestTokens');
                $token = $this->RequestTokens->find()->where(['RequestTokens.token' => $this->request->env('HTTP_TOKEN')])->first();
           
                if (!$token) {
                    header('Content-Type: application/json');
                    $json = array(
                        'status' => HEADERTOKENFAILCODE,
                        'message' => HEADERTOKENFAILMESSAGE,
                    );
                }
            }
        } else {
            if (!is_null($this->request->env('HTTP_AUTHTOKEN'))) {
                $this->loadModel('UserDeviceInfos');
                $token = $this->UserDeviceInfos->find()->where(['auth_token' => $this->request->env('HTTP_AUTHTOKEN')])->first();
                if ($token) {
                    if (!is_null($this->request->env('HTTP_USERID'))) {
                        if ($token->user_id != $this->request->env('HTTP_USERID')) {
                            $json = array(
                                'status' => HEADERTOKENFAILCODE,
                                'message' => HEADERTOKENFAILMESSAGE,
                            );
                        }
                    } else {
                        $json = array(
                            'status' => USERNOTEXISTCODE,
                            'message' => USERNOTEXISTMESSAGE,
                        );
                    }
                } else {
                    $json = array(
                        'status' => HEADERTOKENFAILCODE,
                        'message' => HEADERTOKENFAILMESSAGE,
                    );
                }
            } else {
                $json = array(
                    'status' => AUTHTOKENNOTEXISTCODE,
                    'message' => AUTH_NOT_EXIST,
                );
            }
        }
        if (!empty($json)) {
            $resultJson = json_encode($json);
            $this->response->type('json');
            $this->response->body($resultJson);
            return $this->response;
        }
    }

  /**
   * Log In
   *
   * @return json
   */
  public function login()
    {       
        $json = [];
        $json = $this->Users->verifyDirectLogin($this->request->getData());
        $resultJson = json_encode($json);
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
    }

  /**
   * getMasterData
   *
   * @return json
   */
    public function getMasterData()
    { 
        $this->loadModel('Regions');
        $regions = $this->Regions->find('all', [
                            'conditions' => ['Regions.is_deleted = 0']
                        ])->hydrate(false)->toArray();    
        
        $this->loadModel('Suburbs');
        $suburbs = $this->Suburbs->find('all', [
                            'conditions' => ['Suburbs.is_deleted = 0']
                        ])->hydrate(false)->toArray();
                        
        $this->loadModel('Practices');
        $practices = $this->Practices->find('all', [
                            'conditions' => ['Practices.is_deleted = 0']
                        ])->hydrate(false)->toArray();
                        
        $this->loadModel('Doctors');
        $doctors = $this->Doctors->find('all', [
                            'conditions' => ['Doctors.is_deleted = 0']
                        ])->hydrate(false)->toArray();
         
        $message = SUCCESS;
        $status = SUCCESSCODE;
        $response = ['regions' => $regions, 'suburbs' => $suburbs, 'practices' => $practices, 'doctors' => $doctors];

        $resultJson = json_encode(compact('status', 'message', 'response'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
    }
    /**
    * getRiskData
    *
    * @return json
    */
    public function getRiskData()
    {
       
        $this->loadModel('Risks');
        $risks = $this->Risks->find('all')->hydrate(false)->toArray();    
        
        $this->loadModel('RiskCategories');
        $risk_categories = $this->RiskCategories->find('all', [
                            'conditions' => ['RiskCategories.is_deleted = 0']
                        ])->hydrate(false)->toArray();
                        
        $this->loadModel('RiskSubCategories');
        $risk_sub_categories = $this->RiskSubCategories->find('all', [
                            'conditions' => ['RiskSubCategories.is_deleted = 0']
                        ])->hydrate(false)->toArray();
                        
        $this->loadModel('RiskFactors');
        $risk_factors = $this->RiskFactors->find('all')->hydrate(false)->toArray();
                        
        $this->loadModel('OtoCategories');
        $oto_categories = $this->OtoCategories->find('all')->hydrate(false)->toArray();
                        
         
        $message = SUCCESS;
        $status = SUCCESSCODE;
        $response = ['risks' => $risks, 'risk_categories' => $risk_categories, 'risk_sub_categories' => $risk_sub_categories, 'risk_factors' => $risk_factors, 'oto_categories' => $oto_categories];

        $resultJson = json_encode(compact('status', 'message', 'response'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
    }
    /**
    * saveExpert
    *
    * @return json
    */
    public function saveExpert()
    {
        $json = [];
        if($this->request->is(['post'])) {
            
            $this->loadModel('SelectedExperts');
            
            $this->request->data['user_id'] = $this->request->env('HTTP_USERID');         
            $this->request->data['appref_id'] = $this->request->getData('appId');         
            $this->request->data['suburb_id'] = $this->request->getData('suburbId');         
            $this->request->data['practice_id'] = $this->request->getData('practiceId');         
            $this->request->data['doctor_id'] = $this->request->getData('doctorId');         
            $this->request->data['created_at'] = date("Y-m-d H:i:s");         
            $this->request->data['modified_at'] = date("Y-m-d H:i:s");
            
            $selectedExperts = $this->SelectedExperts->newEntity();        
            $selectedExperts = $this->SelectedExperts->patchEntity($selectedExperts, $this->request->getData());
            if ($this->SelectedExperts->save($selectedExperts)){            
                    $message = SUCCESS;
                    $status = SUCCESSCODE;
                    $response = ['appref_id' => $this->request->getData('appId')];
                    $resultJson = json_encode(compact('status', 'message', 'response'));
            } else {
                    $json = array(
                        'status' => INVALID_CREDENTIALS_CODE,
                        'message' => INVALID_CREDENTIALS_MESSAGE
                      );
                    $resultJson = json_encode($json);
            }
        }   
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;

    }
   /**
   *
   * This method is used to update Employer password
   * without login
   *
   * @return void
   */
    public function forgotPassword()
    {
        $json = [];
        if ($this->request->is(['post'])) {
        //For User role 
         $user = $this->Users->find()->where(['username' => $this->request->getData('username'),'role ='=>1])->first();
            if (is_null($user)) {
                $json = array(
                    'status' => USERNAME_NOT_REGISTERED_CODE,
                    'message' => NO_USERNAME_EXIST_MESSAGE,
                );
            } else {
                $password = $this->Common->generateRandomString(6);
                $user = $this->Users->patchEntity($user, ['password' => $password]);
                if ($this->Users->save($user)) {
                    //send email to user
                    $email = new Email('default');
                    $email->setSender([ADMIN_EMAIL => SITE_NAME])
                            ->setFrom([ADMIN_EMAIL => SITE_NAME])
                            ->setTo($user->email)
                            ->setSubject(PASSWORD_CHANGE_SUBJECT)
                            ->setEmailFormat('html')
                            ->setTemplate('forgot_password_service')
                            ->setViewVars(['user' => $user->toArray(), 'password' => $password])
                            ->send();
                    $json = array(
                        'status' => SUCCESSCODE,
                        'message' => SUCCESS,
                    );
                } else {
                $json = array(
                  'status' => FAILCODE,
                  'message' => FAILMESSAGE,
                );
                }
            }
        }
        $resultJson = json_encode($json);
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
    }

  /**
   * saveRiskClicks
   *
   * @return json
   */
    public function saveRiskClicks()
    {
        $json = [];
        if($this->request->is(['post'])) {
            
            $this->loadModel('UserProfiles');
            
            $this->request->data['user_id'] = $this->request->env('HTTP_USERID');         
            $this->request->data['doctor_id'] = $this->request->getData('doctorId');         
            $this->request->data['app_refid'] = $this->request->getData('appId');               
            $this->request->data['oto_categoryid'] = $this->request->getData('otoCategoryId');         
            $this->request->data['risk_categoryid'] = $this->request->getData('riskCategoryId');         
            $this->request->data['risk_subcategory'] = $this->request->getData('riskSubCategoryId');         
            $this->request->data['risk_factorid'] = $this->request->getData('riskFactorId');         
            $this->request->data['risk_id'] = $this->request->getData('riskId');                
            $this->request->data['start_at'] = $this->request->getData('startAt');        
            $this->request->data['end_at'] = $this->request->getData('endAt');   
            $this->request->data['created_at'] = date("Y-m-d H:i:s");         
            
            $userProfiles = $this->UserProfiles->newEntity();        
            $userProfiles = $this->UserProfiles->patchEntity($userProfiles, $this->request->getData());
            if ($this->UserProfiles->save($userProfiles)){          
                    $message = SUCCESS;
                    $status = SUCCESSCODE;
                    $response = ['appref_id' => $this->request->getData('appId')];
                    $resultJson = json_encode(compact('status', 'message', 'response'));
            } else {
                    $json = array(
                        'status' => INVALID_CREDENTIALS_CODE,
                        'message' => INVALID_CREDENTIALS_MESSAGE
                      );
                    $resultJson = json_encode($json);
            }
        }   
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
 
    }
    
    public function saveNewRiskClicks()
    {
        if($this->request->is(['post'])) {
            
            $this->loadModel('UserProfiles');
            $data = $appref_id = array();
            $data = $this->request->getData('riskData');
            foreach($data as $key=>$value){
                $riskData = array();            
            
                $riskData['user_id'] = $value['userId'];       
                $riskData['doctor_id'] = $value['doctorId']; 
                $riskData['app_refid'] = $value['appId'];               
                $riskData['oto_categoryid'] = $value['otoCategoryId'];         
                $riskData['risk_categoryid'] = $value['riskCategoryId'];         
                $riskData['risk_subcategory'] = $value['riskSubCategoryId'];         
                $riskData['risk_factorid'] = $value['riskFactorId'];         
                $riskData['risk_id'] = $value['riskId'];                
                $riskData['start_at'] = $value['startAt'];        
                $riskData['end_at'] = $value['endAt'];   
                $riskData['created_at'] = date("Y-m-d H:i:s");  
            
            
                $userProfiles = $this->UserProfiles->newEntity();        
                $userProfiles = $this->UserProfiles->patchEntity($userProfiles, $riskData);
                if ($this->UserProfiles->save($userProfiles)){          
                        $message = SUCCESS;
                        $status = SUCCESSCODE;
                        $appref_id[] = $value['appId'];
                }
                else{
                        $message = INVALID_CREDENTIALS_CODE;
                        $status = INVALID_CREDENTIALS_MESSAGE;
                        unset($appref_id[$key]);
                }
            }
            
            $response = ['appref_id' => $appref_id];
            $resultJson = json_encode(compact('status', 'message', 'response'));
        }   
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
         
     
    }
    /**
    * savePdfClicks
    *
    * @return json
    */
    public function savePdfClicks()
    {
        if($this->request->is(['post'])) {          
            $this->loadModel('PdfClicks');
            $this->loadModel('PdfPageClicks');
            $token_id = $this->request->env('HTTP_AUTHTOKEN');  
            $data = $appref_id = array();
            $data = $this->request->getData('pdfAccess');
            foreach($data as $value){
                $pdfData = $pdfClicks = array();
                //old webservice use token id & app ref id
                $user_id = 0;
                $user_id = $value['userId'];
                
                $pdfClicks = $this->PdfClicks->find('all')
                                ->where(['PdfClicks.token_id =' => $token_id,'PdfClicks.app_refid =' => $value['appId']])   
                                ->select(['PdfClicks.id'])                              
                                ->hydrate(false)                                    
                                ->toArray();        
                    if(count($pdfClicks) == 0){
                        $pdfData['token_id'] = $token_id;       
                        $pdfData['user_id'] = $user_id;       
                        $pdfData['doctor_id'] = $value['doctorId'];       
                        $pdfData['pdf_id'] = $value['pdfId'];       
                        $pdfData['app_refid'] = $value['appId'];                
                        $pdfData['device_app_refid'] = $value['deviceRefId'];     
                        $pdfData['start_at'] = $value['startAt'];        
                        $pdfData['end_at'] = $value['endAt'];   
                        $pdfData['created_at'] = date("Y-m-d H:i:s");         
                        $pdfData['updated_at'] = date("Y-m-d H:i:s"); 
                        $pdfInsert = $this->PdfClicks->newEntity();        
                        $pdfProfiles = $this->PdfClicks->patchEntity($pdfInsert, $pdfData);
                        $this->PdfClicks->save($pdfProfiles);
                        $appref_id[]  = $value['appId'];                
                    }
                    $appref_id[] = $value['appId'];
                    if(isset($value['pageAccess']) && count($value['pageAccess']) >0){
                        $val = $page_appref_id = array();
                        foreach($value['pageAccess'] as $val){
                            $pageData = $pdfPageClicks = $pageClicks =array();  
                            //Token Id used in old webservice   
                            $pdfPageClicks = $this->PdfClicks->find()
                                            ->where(['PdfClicks.token_id =' => $token_id,'PdfClicks.app_refid =' => $val['pdfAccessId']])   
                                            ->select(['PdfClicks.id','PdfClicks.pdf_id'])
                                            ->first();

                                if(count($pdfPageClicks)>0){                                            
                                    $pageData['pdf_accessid'] = $pdfPageClicks->id;   
                                    $pageData['app_refid'] = $val['pageAccessId'];                                                      
                                    $pageData['token_id'] = $token_id;       
                                    $pageData['user_id'] = $user_id;       
                                    $pageData['doctor_id'] = $val['doctorId'];                      
                                    $pageData['page_id'] = $val['pageId'];                          
                                    $pageData['pdf_id'] = $pdfPageClicks->pdf_id;                               
                                    $pageData['device_app_refid'] = $val['deviceRefId'];     
                                    $pageData['start_at'] = $val['startAt'];        
                                    $pageData['end_at'] = $val['endAt'];   
                                    $pageData['created_at'] = date("Y-m-d H:i:s");         
                                    $pageData['updated_at'] = date("Y-m-d H:i:s");       
                                
                                    $pageClicks = $this->PdfPageClicks->find()
                                                        ->where(['PdfPageClicks.pdf_accessid =' => $pdfPageClicks->id,'PdfPageClicks.app_refid =' => $val['pageAccessId']]) 
                                                        ->select(['PdfPageClicks.id'])
                                                        ->first();
                                    if(count($pageClicks)==0){                      
                                        $pageInsert = $this->PdfPageClicks->newEntity();        
                                        $pageProfiles = $this->PdfPageClicks->patchEntity($pageInsert, $pageData);
                                        $this->PdfPageClicks->save($pageProfiles);
                                    }
                                    $page_appref_id[] = $val['pageAccessId'];
                                            
                                    }
                        }      
                 }
                $output[] = ['appref_id' => $appref_id,'page_appref_id' => $page_appref_id];    
            }
            $response = $output;
            $message = SUCCESS;
            $status = SUCCESSCODE;
            $resultJson = json_encode(compact('status', 'message', 'response'));        
        }
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
    }
    
    /**
    * updatePassword
    *
    * @return json
    */

    public function updatePassword()
    {
        $json = [];
        $user = $this->Users->get($this->request->getData('id'));
        if ($this->request->is(['patch', 'post', 'put'])) {

            $user = $this->Users->patchEntity($user, $this->request->getData());
            $user->pwd_reset_req = NOT_ACTIVE;
            if ($this->Users->save($user)) {
                $json = array(
                    'status' => SUCCESSCODE,
                    'message' => SUCCESS,
                );
            } else {
                $json = array(
                    'status' => FAILCODE,
                    'message' => FAILMESSAGE,
                );
            }
        }
        $resultJson = json_encode($json);
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
    }
    
    /**
    * @return json
    */
    public function logout()
    {
        $userDeviceInfo = $this->Users->UserDeviceInfos->find()->select(['id'])
            ->where(['auth_token' => $this->request->env('HTTP_AUTHTOKEN'), 'user_id' => $this->request->env('HTTP_USER_ID')])->first();
        if ($this->Users->UserDeviceInfos->delete($userDeviceInfo)) {
            $json = array(
                STATUS => SUCCESSCODE,
                MESSAGE => SUCCESS,
            );
        } else {
            $json = array(
                STATUS => FAILCODE,
                MESSAGE => FAILMESSAGE,
            );
        }
        $resultJson = json_encode($json);
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
    }
    /**
    * @return json
    */
    public function getBrands()
    {
        $json = [];
        $this->loadModel('UsersBrands');
        $userId = $this->request->env('HTTP_USERID');
        $userBrands = $this->UsersBrands->find('all')->where(['UsersBrands.user_id' => $userId ]) ->hydrate(false)->toArray();
        if(!empty($userBrands)){
           $ids = array();
            foreach($userBrands as $UsersBrandsInfo)
            {
                $ids[] = $UsersBrandsInfo['brand_id'];
            } 
            $this->loadModel('Brands');
            $brands = $this->Brands->find('all')
                        ->where(['brand_id IN' => $ids,'is_deleted = 0'])->contain(['Menues','Packshots'])->hydrate(false)->toArray();                           
            $this->loadModel('Menues');
            $menues = $this->Menues->find('all')
                        ->where(['brand_id = 0'])->hydrate(false)->toArray();       
            foreach($brands as $key => $brand_name)
            {
                $brands[$key]['button_image'] = SITE_URL.'images/buttonImage/'.$brand_name['button_image'];
                $brands[$key]['logo_image'] = SITE_URL.'images/logoImage/'.$brand_name['logo_image'];
                $brands[$key]['packshot_image'] = SITE_URL.'images/packshotImage/'.$brand_name['packshot_image'];
                $brands[$key]['advert_pdf_path'] = 'brandAdvertPdf/'.$brand_name['advert_pdf_path'];
                if(!empty($brands[$key]['packshots'])) {
                    foreach($brand_name['packshots'] as $key1 => $row) {
                        if($brands[$key]['packshots'][$key1]['file_path']!= '' && $brands[$key]['packshots'][$key1]['file_type'] == '0') {
                            $brands[$key]['packshots'][$key1]['file_path'] = 'packshot/pdf/'.$row['file_path'];
                        }else{
                            $brands[$key]['packshots'][$key1]['file_path'] = 'packshot/video/'.$row['file_path'];
                        }   
                    }
                }
                if(!empty($brands[$key]['menues'])) {
                    foreach($brand_name['menues'] as $key2 => $row2) {
                        if($brands[$key]['menues'][$key2]['file_path']!= '' && $brands[$key]['menues'][$key2]['file_type'] == '0') {
                            $brands[$key]['menues'][$key2]['file_path'] = 'menu/pdf/'.$row2['file_path'];
                        }else {
                            $brands[$key]['menues'][$key2]['file_path'] = 'menu/video/'.$row2['file_path'];
                        }
                    }
                }
            }
            foreach($menues as $key => $menu_name)
            {
                $menues[$key]['file_path'] = 'menu/pdf/'.$menu_name['file_path'];
            }
            $message = SUCCESS;
            $status = SUCCESSCODE;
            $response = ['brands' => $brands,'menu'=> $menues];
            $resultJson = json_encode(compact('status', 'message', 'response'));
            $this->response->type('json');
            $this->response->body($resultJson);
            return $this->response;
        }   
        else{
            $json = array(
                'status' => FAILCODE,
                'message' => FAILMSGBRANDS,
            );
            $resultJson = json_encode($json);
            $this->response->type('json');
            $this->response->body($resultJson);
            return $this->response;
        }
    }   
}





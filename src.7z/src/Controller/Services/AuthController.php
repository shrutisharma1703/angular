<?php
namespace App\Controller\Services;

use App\Controller\AppController;
use Cake\Event\Event;

class AuthController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('Common');
    }

      /**
       * Before filter callback.
       *
       * @param \Cake\Event\Event $event The beforeRender event.
       * @return \Cake\Network\Response|null|void
       */
    public function beforeFilter(Event $event)
    {
    
        $this->eventManager()->off($this->Csrf);
        $this->Security->config('unlockedActions', ['versionCheck']);

        $init_actions = ['versionCheck'];
        if (in_array($this->request->action, $init_actions)) { 
            if (!isset($_SERVER['HTTP_TOKEN'])) {
                $resultJson = json_encode(array(
                    'status' => HEADERTOKENFAILCODE,
                    'message' => HEADERTOKENMISSINGMESSAGE,
                ));
                $this->response->type('json');
                $this->response->body($resultJson);
                return $this->response;
            }
            $this->loadModel('RequestTokens');
            $options = array(
                'conditions' => array(
                'RequestTokens.token' => $_SERVER['HTTP_TOKEN'],
                ),
            );
            $tokens = $this->RequestTokens->find('all', $options);
            if (!$tokens->count()) {
                header('Content-Type: application/json');
                $resultJson = json_encode(array(
                    'status' => HEADERTOKENFAILCODE,
                    'message' => HEADERTOKENFAILMESSAGE,
                ));
                $this->response->type('json');
                $this->response->body($resultJson);
                return $this->response;
            }
        }
    }

  /**
   * Get Token callback.
   *
   * @return json
   */
    public function getToken()
    { 
        if ($this->request->is(['post', 'get'])) {
            $this->loadModel('RequestTokens');
            $data = $this->request->input('json_decode');
          
            $json = [];
            if ((strcasecmp($_SERVER['HTTP_CLIENT_ID'], APP_TOKEN_CLIENT) == 0) && (strcasecmp($_SERVER['HTTP_CLIENT_SECRET'], APP_TOKEN_SECRET) == 0)) {
              
                $authtoken = $this->Common->generateRandomString(32);
                $token_expiredate = date('Y-m-d H:i:s', strtotime(TOKEN_EXPIRES_DAYS . " days"));
                $data = array(
                    'token' => $authtoken,
                    'expiration' => $token_expiredate,
                );
                $requestToken = $this->RequestTokens->newEntity();
                $requestToken = $this->RequestTokens->patchEntity($requestToken, $data);
                $this->RequestTokens->save($requestToken);
                $json = array(
                    'status' => SUCCESSCODE,
                    'response' => $authtoken,
                    'message' => SUCCESS,
                );
            } else {
                $json = array(
                    'status' => TOKENFAILCODE,
                    'message' => TOKENFAILMESSAGE,
                );
            }
            $resultJson = json_encode($json);
            $this->response->type('json');
            $this->response->body($resultJson);
            return $this->response;
        }
    }

  /**
   * Version Check callback.
   *
   * @return json
   */
    public function versionCheck()
    {
        if ($this->request->getData('version') && !is_null($this->request->getData('device_type'))) {
            $version = unserialize(MINIMUM_VERSION);
            if ($this->request->getData('version') >= $version[$this->request->getData('device_type')]) {
                $json = array(
                    'status' => SUCCESSCODE,
                    'message' => SUCCESS,
                );
            } else {
                $json = array(
                    'status' => VERSIONUPDATECODE,
                    'message' => VERSIONUPDATEMESSAGE,
                );
            }
        } else {
            $json = array(
                'status' => FAILCODE,
                'message' => INVALID_REQUEST,
            );
        }
        $resultJson = json_encode($json);
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
    }
}

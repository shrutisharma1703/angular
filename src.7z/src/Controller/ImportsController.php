<?php
namespace App\Controller;

use App\Controller\AppController;

    /**
    * Imports Controller
    *
    * @property \App\Model\Table\DoctorsTable $Doctors
    */
class ImportsController extends AppController
{
    /**
    * Initialization hook method.
    *
    * Use this method to add common initialization code like loading components.
    *
    * e.g. `$this->loadComponent('Security');`
    *
    * @return void
    */
    public function initialize(){
        parent::initialize();
        $this->loadComponent('Imports');
    } 
   
    public function index()
    {
        $this->viewBuilder()->setLayout('admin');
        if ($this->request->is('post')) {
        $result = [];
        switch ($this->request->getData('type')) {
            case USER_IMPORT:
                $result = $this->Imports->importUsers();
                break;
            case SUBURBS_IMPORT:
                $result = $this->Imports->importSuburbs();
                break;
            case PRACTICES_IMPORT:
                $result = $this->Imports->importPractices();
                break;
            case DOCTORS_IMPORT:
                $result = $this->Imports->importDoctors();
                break;
            case REGIONS_IMPORT:
                $result = $this->Imports->importRegions();
                break;
            default:
            break;
        }
        if (isset($result['success'])) {
            $this->Flash->success(__($result['success']));
        }
        if (isset($result['error'])) {
            foreach ($result['error'] as $error) {
                $this->Flash->error(__($error));
            }
        }
    }
        $importTypes = unserialize(IMPORT_TYPE);
            $this->set(compact('importTypes'));
    }
    
    public function download($name)
    {
        $import_types = unserialize(IMPORT_TYPE);
        $name = $import_types[$name];
        $file_path = WWW_ROOT . 'uploads' . DS . 'import-csv' . DS . strtolower($name) . '.csv';
        return $this->response->withFile(
            $file_path,
            ['download' => true, 'name' => strtolower($name) . '.csv']
        );
    }
    
    public function documentation()
    {
        $this->viewBuilder()->setLayout('admin');
    }
}

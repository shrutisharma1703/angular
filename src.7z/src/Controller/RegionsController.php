<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Regions Controller
 *
 * @property \App\Model\Table\RegionsTable $Regions
 */
class RegionsController extends AppController
{
    
    public function initialize(){
        parent::initialize();
        $this->viewBuilder()->setLayout('admin');
    } 
    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        
        $regions = $this->paginate($this->Regions);
        $this->set(compact('regions'));
        $this->set('_serialize', ['regions']);
    }

    /**
     * View method
     *
     * @param string|null $id Region id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        
        $region = $this->Regions->get($id, [
            'contain' => []
        ]);
        $this->set('region', $region);
        $this->set('_serialize', ['region']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $region = $this->Regions->newEntity();
        if ($this->request->is('post')) {
            $this->request->data['created_at'] = $this->request->data['updated_at'] = date("Y-m-d H:i:s");        
            $region = $this->Regions->patchEntity($region, $this->request->getData());
            if ($this->Regions->save($region)) {
                $this->Flash->success(__('The region has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
           $this->Flash->error(__('The region could not be saved. Please, try again.'));
            
        }
        $this->set(compact('region'));
        $this->set('_serialize', ['region']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Region id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $region = $this->Regions->get($id, [
            'contain' => []
        ]);
          $this->set('region_name',$region->name);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $this->request->data['updated_at'] = date("Y-m-d H:i:s");
            $region = $this->Regions->patchEntity($region, $this->request->getData());
            if ($this->Regions->save($region)) {
                $this->Flash->success(__('The region has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The region could not be saved. Please, try again.'));
            
        }
        $this->set(compact('region'));
        $this->set('_serialize', ['region']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Region id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
		$regions = $this->Regions->find('all')->select(['name'])->where(['id' => $id])->first();
		$this->loadModel('Suburbs');
		$suburb = $this->Suburbs->find('all')->select(['id'])->where(['region_id' => $id])->first();
		$this->loadModel('Practices');
		$practice = $this->Practices->find('all')->select(['id'])->where(['region_id' => $id])->first();
		$this->loadModel('Doctors');
		$doctor = $this->Doctors->find('all')->select(['id'])->where(['region_id' => $id])->first();
		if($suburb['id'] == '' && $practice['id'] == '' && $doctor['id'] == ''){
			$region = $this->Regions->get($id);
			if ($this->Regions->delete($region)) {
				$this->Flash->success(__('The region '.$regions['name'].' has been deleted.'));
			} else {
				$this->Flash->error(__('The region could not be deleted. Please, try again.'));
			}
		}else{
			$this->Flash->error(__('In Order to delete Region ('.$regions['name'].'), Please delete associated Relation with Suburbs or Practices or Doctors.'));	
		}
		return $this->redirect(['action' => 'index']);
		
    }
    
    public function toggleStatus()
    {
        $this->autoRender = false;
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = [];
            $status = $this->request->getData('status');
            foreach ($this->request->getData('ids') as $region_id) {
                $data[] = ['is_deleted' => $status, 'id' => $region_id];
            }
            $regions = $this->Regions->find()->where(['id in' => $this->request->getData('ids')]);
            $this->Regions->patchEntities($regions, $data);
            if ($this->Regions->saveMany($regions)) {
                echo DONE;
            } else {
                echo NOT_DONE;
            }
        }
    }
    /**
    * Show method
    *
    * @return \Cake\Network\Response|null
    */
    public function show()
    {
        $limit = ADMIN_PAGINATION_LIMIT;
        $offset = ($this->request->query(START)) ? $this->request->query(START) : 0;
        $conditions = $order = [];
        if ($this->request->query('order') && $this->request->query('order.0')) 
        {
            switch ($this->request->query('order.0.column')) {
                case 0:
                $order = ['Regions.name ' . $this->request->query('order.0.dir')];
                break;
                case 1:
                $order = ['Regions.created_at ' . $this->request->query('order.0.dir')];
                break;
                default:
                $order = ['Regions.id DESC'];
                break;
            }
        }
        else {
            $order = ['Regions.id DESC'];
        }
        if ($this->request->query('search.value')) {
            $conditions[] = ['Regions.name LIKE' => '%' . $this->request->query('search.value') . '%'];
        }
        $totalRegions = $this->Regions->find('all', ['conditions' => $conditions]);

        $Regions = $this->Regions->find('all', [
            'conditions' => $conditions,
            'offset' => $offset,
            'limit' => $limit,
            'order' => $order,

        ]);

        $data = [];
        $draw = 0;
        $recordsTotal = $totalRegions->count();
        $recordsFiltered = $Regions->count();
        foreach ($Regions as $region) {
            $record = [];
            $record[] = $region->name;
            $record[] = date('Y-m-d', strtotime($region->created_at));
            $record[] = '&nbsp;&nbsp;<a title="View" href="/Regions/view/' . $region->id . '"><i class="fa fac-info"></i></a>&nbsp;&nbsp;<a title="Edit" href="/Regions/edit/' . $region->id . '"><i class="fa fac-edit"></i></a>&nbsp;&nbsp;<a onclick="toggleStatus(\'/Regions/toggleStatus\',\'' . $region->id . '\')" href="javascript:void(0)" title="' . (($region->is_deleted) ? 'Deactivate' : 'Activate') . '" ><i class="active_' . $region->id . ' fa fac-' . (($region->is_deleted) ? 'deactive' : 'active') . '-action"></i></a>&nbsp;&nbsp;<a title="Delete" href="/Regions/delete/' . $region->id . '"><i class="fa fac-trash"></i></a>';
            $data[] = $record;
        }
        $resultJson = json_encode(compact('draw', 'data', 'recordsTotal', 'recordsFiltered', START, 'length'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;

    }
}

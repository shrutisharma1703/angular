<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Menues Controller
 *
 * @property \App\Model\Table\MenuesTable $Menues
 */
class MenuesController extends AppController
{

        public function initialize(){
            parent::initialize();
            $this->viewBuilder()->setLayout('admin');
            $this->loadComponent('Security');
            $this->loadComponent('Csrf');        
            $this->loadComponent('Cookie', ['expires' => '+10 days']);
            $actions = [
              'setOrder'
            ];

            if (in_array($this->request->params['action'], $actions)) {
              // for csrf
              $this->eventManager()->off($this->Csrf);

              // for security component
              $this->Security->config('unlockedActions', $actions);
            }
        } 

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $menues = $this->paginate($this->Menues);
        $this->set(compact('menues'));
        $this->set('_serialize', ['menues']);
    }

    /**
     * View method
     *
     * @param string|null $id Menue id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $menue = $this->Menues->get($id, [
            'contain' => []
        ]);
        $menue['brand_name']  = $this->Common->fetchMenuName('Brands', $menue->brand_id, 'brand_name');
        $menue['aws_video']  = $this->Common->readVideo(AWS_BUCKET_DEV, MENU_BUCKET.DIRECTORY_SEPARATOR.'video'.DIRECTORY_SEPARATOR.$menue->file_path);
        $menue['aws_pdf']  = $this->Common->readVideo(AWS_BUCKET_DEV, MENU_BUCKET.DIRECTORY_SEPARATOR.'pdf'.DIRECTORY_SEPARATOR.$menue->file_path);
        $this->set('menue', $menue);
        $this->set('_serialize', ['menue']);
    }
    
    public function toggleStatus()
    {
        $this->autoRender = false;
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = [];
            $status = $this->request->getData('status');
            foreach ($this->request->getData('ids') as $user_id) {
                $data[] = ['is_deleted' => $status, 'menues_id' => $user_id];
            }
            $menues = $this->Menues->find()->where(['menues_id in' => $this->request->getData('ids')]);
            $this->Menues->patchEntities($menues, $data);
            if ($this->Menues->saveMany($menues)) {
                echo DONE;
            } else {
                echo NOT_DONE;
            }
        }
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->loadModel('Brands');
        $menue = $this->Menues->newEntity();
        if ($this->request->is('post')) {
            if($this->request->data['brand_id'] == ""){
                $query = $this->Menues->find(); 
                $order = $query->select(['order_no' => $query->func()->max('order_no')])->where(['brand_id' =>0])->first(); 
                $this->request->data['order_no'] = ($order['order_no'])+1;
            }else{
                $query = $this->Menues->find(); 
                $order = $query->select(['order_no' => $query->func()->max('order_no')])->where(['brand_id' => $this->request->data['brand_id']])->first(); 
                $this->request->data['order_no'] = ($order['order_no'])+1;
            }
            $this->request->data['created_at'] = $this->request->data['created_at'] = date("Y-m-d H:i:s");          
            $this->request->data['updated_at'] = $this->request->data['updated_at'] = date("Y-m-d H:i:s");  
            $type = $this->request->data('file_type');
            $menuFile = $this->Common->imageFileValues($this->request->getData('file_path'));
            if ($menuFile[TEMP_NAME] == '') {
                unset($this->request->data['file_path']);
            } else {
                $this->request->data['file_path'] = $menuFile['name'];
            }
            $arr_ext = [];
            $folder = '';
            if($type == 0){
                $arr_ext = array('pdf');
                $folder = 'menuPdf';
            }else{
                $arr_ext = array('mp4','3gp','mov','m4v','3g2');
                $folder = 'menuVideo';
            }  
            $menue = $this->Menues->patchEntity($menue, $this->request->getData());
            
            if(!empty($this->request->data['file_path']) && !in_array($menuFile['ext'], $arr_ext))
            {
                $this->Flash->error(__(INVALID_FILE));
            }else{                        
                if ($this->Menues->save($menue)) {
                    if ($menuFile[TEMP_NAME] != '') {
                        try {
                            $this->Common->awsMenuUpload($menuFile[TEMP_NAME], $menuFile['name'], $menuFile['size'], $menuFile['ext'], $folder,$type);
                        } catch (Exception $ex) {
                            $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                        }
                    }
                    $this->Flash->success(__('The menu has been saved.'));

                    return $this->redirect(['action' => 'index']);
                }else{
					$this->Flash->error(__('The menu could not be saved. Please, try again.'));
				}
            }
        }

        $this->set(compact('menue'));
        $this->set('_serialize', ['menue']);
        $this->set('brands',$this->Common->menuesFetchList('Brands', 'is_deleted', 0));
        $this->set('parentMenues',$this->Common->fetchList('Menues', 'is_deleted', 0));

    }

    /**
     * Edit method
     *
     * @param string|null $id Menue id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $menue = $this->Menues->get($id, [
            'contain' => []
        ]);
        $menue['aws_video']  = $this->Common->readVideo(AWS_BUCKET_DEV, MENU_BUCKET.DIRECTORY_SEPARATOR.'video'.DIRECTORY_SEPARATOR.$menue->file_path);
        $menue['aws_pdf']  = $this->Common->readVideo(AWS_BUCKET_DEV, MENU_BUCKET.DIRECTORY_SEPARATOR.'pdf'.DIRECTORY_SEPARATOR.$menue->file_path);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $this->request->data['updated_at'] = $this->request->data['updated_at'] = date("Y-m-d H:i:s");    
            $type = $this->request->data('file_type');
            $menuFile = $this->Common->imageFileValues($this->request->getData('file_path'));
            if ($menuFile[TEMP_NAME] == '') {
                unset($this->request->data['file_path']);
            } else {
                $this->request->data['file_path'] = $menuFile['name'];
            }
            $arr_ext = [];
            $folder = '';
            if($type == 0){
                $arr_ext = array('pdf');
                $folder = 'menuPdf';
            }else{
                $arr_ext = array('mp4','3gp','mov','m4v','3g2');
                $folder = 'menuVideo';
            }
            $menue = $this->Menues->patchEntity($menue, $this->request->getData());
            //set allowed extensions
            if(!empty($this->request->data['file_path']) && !in_array($menuFile['ext'], $arr_ext))
            {
                $this->Flash->error(__(INVALID_FILE));
            }else{
                if ($this->Menues->save($menue)) {
                    if ($menuFile[TEMP_NAME] != '') {
                            try {
                                $this->Common->awsMenuUpload($menuFile[TEMP_NAME], $menuFile['name'], $menuFile['size'], $menuFile['ext'], $folder,$type);
                            } catch (Exception $ex) {
                                $this->Flash->error(__(IMAGE_NOT_UPLOADED));
                            }
                        }
                    $this->Flash->success(__('The menue has been saved.'));
                    return $this->redirect(['action' => 'index']);
                }else{
					$this->Flash->error(__('The menue could not be saved. Please, try again.'));
				}
            }
        }
        $this->set(compact('menue'));
        $this->set('_serialize', ['menue']);
        $this->set('brands',$this->Common->menuesFetchList('Brands', 'is_deleted', 0));
        $this->set('parentMenues',$this->Common->fetchList('Menues', 'is_deleted', 0));
    }

    /**
     * Delete method
     *
     * @param string|null $id Menue id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $menue = $this->Menues->get($id);
        if ($this->Menues->delete($menue)) {
            $this->Flash->success(__('The menue has been deleted.'));
        } else {
            $this->Flash->error(__('The menue could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
    
    public function setOrder()
    {
        $this->loadModel('Brands');
        $this->viewBuilder()->setLayout(ADMIN);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = [];
        foreach ($this->request->getData('menues_id') as $order => $menu_id) {
            $data[] = ['order_no' => $order+1, 'menues_id' => $menu_id];
        }
        $menues = $this->paginate($this->Menues);
        $this->Menues->patchEntities($menues, $data);
        if ($this->Menues->saveMany($menues)) {
            $this->Flash->success(__(MENU_ORDER));
            return $this->redirect(['action' => 'index']);
        }
        }
        $menues = $this->paginate($this->Menues, ['order' => ['order_no' => 'asc']]);
        $brands = $this->Brands->find()->select(['brand_name'])->toArray();
        $this->set(compact('brands','menues'));
    }

    public function getMenuesByBrand(){  
        $this->autoRender = false;
        $menues = [];
        $count = 0;
        if ($this->request->is(['patch', 'post', 'put']) ) {
            $this->loadModel('Brands');
            if($this->request->getData('brand_id') == 'General'){
                $menues = $this->Menues->find('all')->where(['brand_id ' => 0]);
                $count = $menues->count();
                $menues = $menues->toArray();
            }
            else{
                $brands = $this->Brands->find('all')->select('brand_id')->where(['brand_name LIKE' => "%".$this->request->getData('brand_id')."%"])->hydrate(false)->toArray();
                $this->loadModel('Menues'); 
                foreach($brands as $brandId){
                    $brand_id= $brandId['brand_id'];
                }       
                $menues = $this->Menues->find('all')->where(['brand_id ' => $brand_id])->order(['order_no' => 'ASC']);   
                $count = $menues->count();
                $menues = $menues->toArray();
            }
        }
        $resultJson = json_encode(compact('menues','count'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response; 
    }
    
   /**
   * Show method
   *
   * @return \Cake\Network\Response|null
   */
    public function show()
    {
        $limit = ADMIN_PAGINATION_LIMIT;
        $offset = ($this->request->query(START)) ? $this->request->query(START) : 0;
        $conditions = $order = [];
        if ($this->request->query('order') && $this->request->query('order.0')) {
        {
            switch ($this->request->query('order.0.column')) {
              case 0:
                $order = ['Menues.name ' . $this->request->query('order.0.dir')];
                break;
              case 1:
                $order = ['Menues.brand_id ' . $this->request->query('order.0.dir')];
                break;
              default:
                $order = ['Menues.menues_id DESC'];
                break;
            }
        }
        }else {
            $order = ['Menues.brand_id ASC,Menues.order_no ASC'];
        }
        if ($this->request->query('search.value')) {
            $conditions[] = ['Menues.name LIKE' => '%' . $this->request->query('search.value') . '%'];
        }
    
        $totalMenues = $this->Menues->find('all', ['conditions' => $conditions]);
        $menues = $this->Menues->find('all', [
            'conditions' => $conditions,
            'offset' => $offset,
            'limit' => $limit,
            'order' => $order,
        ]);
    
        $data = [];
        $draw = 0;
        $recordsTotal = $totalMenues->count();
        $recordsFiltered = $menues->count();
        foreach ($menues as $menu) {
            $record = [];
            $record[] = $menu->name;
            $record[] = $this->Common->fetchMenuName('Brands', $menu->brand_id, 'brand_name');
            if($menu->file_type == '0'){
                $type = 'PDF';
            }else{
                $type = 'Video';
            }
            $record[] = $type;
            $record[] = $menu->order_no;
            $record[] = date('Y-m-d', strtotime($menu->created_at));
            $record[] = '&nbsp;&nbsp;<a title="View" href="/Menues/view/' . $menu->menues_id . '"><i class="fa fac-info"></i></a>&nbsp;&nbsp;<a title="Edit" href="/Menues/edit/' . $menu->menues_id . '"><i class="fa fac-edit"></i></a>&nbsp;&nbsp;<a onclick="toggleStatus(\'/Menues/toggleStatus\',\'' . $menu->menues_id . '\')" href="javascript:void(0)" title="' . (($menu->is_deleted) ? 'Deactivate' : 'Activate') . '" ><i class="active_' . $menu->menues_id . ' fa fac-' . (($menu->is_deleted) ? 'deactive' : 'active') . '-action"></i></a>';
            $data[] = $record;
        }
        $resultJson = json_encode(compact('draw', 'data', 'recordsTotal', 'recordsFiltered', START, 'length'));
        $this->response->type('json');
        $this->response->body($resultJson);
        return $this->response;
    }
    

}

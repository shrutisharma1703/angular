<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Risks Controller
 *
 * @property \App\Model\Table\RisksTable $Risks
 */
class RisksController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $risks = $this->paginate($this->Risks);

        $this->set(compact('risks'));
        $this->set('_serialize', ['risks']);
    }

    /**
     * View method
     *
     * @param string|null $id Risk id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $risk = $this->Risks->get($id, [
            'contain' => ['RiskSubCategories']
        ]);

        $this->set('risk', $risk);
        $this->set('_serialize', ['risk']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $risk = $this->Risks->newEntity();
        if ($this->request->is('post')) {
            $risk = $this->Risks->patchEntity($risk, $this->request->getData());
            if ($this->Risks->save($risk)) {
                $this->Flash->success(__('The risk has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The risk could not be saved. Please, try again.'));
        }
        $this->set(compact('risk'));
        $this->set('_serialize', ['risk']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Risk id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $risk = $this->Risks->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $risk = $this->Risks->patchEntity($risk, $this->request->getData());
            if ($this->Risks->save($risk)) {
                $this->Flash->success(__('The risk has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The risk could not be saved. Please, try again.'));
        }
        $this->set(compact('risk'));
        $this->set('_serialize', ['risk']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Risk id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $risk = $this->Risks->get($id);
        if ($this->Risks->delete($risk)) {
            $this->Flash->success(__('The risk has been deleted.'));
        } else {
            $this->Flash->error(__('The risk could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}

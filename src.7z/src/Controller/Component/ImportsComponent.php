<?php
namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Cake\Utility\Security;

class ImportsComponent extends Component
{
  /**
   * Import Restaurants functionality.
   *
   * @return @array
   */
    public function importUsers()
    {
        $response = [];
        if ($this->request->getData(CSV_ERROR_FILE)) {
            $response[ERRORS][] = ERROR_IN_CSV;
        } elseif ($this->request->getData(CSV_FILE)) {
            $this->Users = TableRegistry::get('users');
            $filename = explode('.', $this->request->getData(CSV_FILE_NAME));
            $extension = $filename[count($filename) - 1];
            if ($extension == 'csv') {
                $handle = fopen($this->request->getData(CSV_FILE), "r");
                $users = $ids = [];
                $csvHeaders = fgetcsv($handle, 10000, ",", '"');
            if (unserialize(USER_IMPORT_FIELDS) != $csvHeaders) {
                $response[ERRORS][] = INVALID_IMPORT_FIELDS;
                return $response;
            }
            while ($data = fgetcsv($handle, 10000, ",", '"')) {
				$userData = [];
                $this->Doctors = TableRegistry::get('Doctors');
                $doctor_name = explode(',',$data[10]);
                $doctorsList = $this->Doctors->find('all')->select(['id','region_id','suburb_id','practice_id'])->where(['first_name IN' => $doctor_name])->toArray();
                
                $regions = $suburbs = $practices = $doctors = $doctorData = array();
                foreach($doctorsList as $doctor){
					$regions[] = $doctor['region_id'];
					$suburbs[] = $doctor['suburb_id'];
					$practices[] = $doctor['practice_id'];
					$doctors[] = $doctor['id'];
				}
			
                $userData['doctorsDetails'] = $doctorsList;
                $user = $this->Users->find()->where(['OR' => ['username' => $data[2], 'email' => $data[3]]])->first();
               
                if ($user) {
                    $ids[] = $userData['id'] = $user->id;
                } 
                
                $user = [
                    'first_name' => $data[0],
                    'last_name' => $data[1],
                    'username' => $data[2],
                    'email' => $data[3],
                    'password' => Security::hash($data[4], 'sha1', true),
                    'title' => $data[5],
                    'position' => $data[6],
                    'image_path' => $data[7],
                    'role' => $data[8],
                    'is_active' => $data[9],
                    'created_date' => date("Y-m-d H:i:s"),
                    'modified_date' => date("Y-m-d H:i:s"),
                    'doctors' => [
							'_ids' => $doctors
					],
                ];
                $userData = array_merge($userData, $user);
                $users[] = $userData;          
            }
            if (empty($users)) {
                $response[ERRORS][] = NO_IMPORT_RECORD;
            }else if(empty($userData['doctorsDetails']))
            {
                $response[ERRORS][] = 'No Record Find for this Doctors.';
            } else {
                $userToEdit = $this->Users->find()->where(['id in' => implode(',', $ids)]);
                $users['created_date'] = $users['modified_date'] = date("Y-m-d H:i:s");
                $users = $this->Users->patchEntities($userToEdit, $users);  
                if ($this->Users->saveMany($users)) {
                    $response[SUCCESS] = USERS_IMPORTED;
                } else {
                    $response[ERRORS][] = $this->getError($users);
                }
			}
            } else {
                $response[ERRORS][] = INVALID_IMPORT_FILE;
            }
        } else {
            $response[ERRORS][] = CSV_NOT_UPLOADED;
        }
        return $response;
    }
  
    public function importSuburbs()
    {
        $response = [];
        if ($this->request->getData(CSV_ERROR_FILE)) {
            $response[ERRORS][] = ERROR_IN_CSV;
        } elseif ($this->request->getData(CSV_FILE)) {
            $this->Suburbs = TableRegistry::get('suburbs');
            $filename = explode('.', $this->request->getData(CSV_FILE_NAME));
            $extension = $filename[count($filename) - 1];
            if ($extension == 'csv') {
                $handle = fopen($this->request->getData(CSV_FILE), "r");
                $suburbs = $ids = [];
                $csvHeaders = fgetcsv($handle, 10000, ",", '"');
            if (unserialize(SUBURB_IMPORT_FIELDS) != $csvHeaders) {
                $response[ERRORS][] = INVALID_IMPORT_FIELDS;
                return $response;
            }
            while ($data = fgetcsv($handle, 10000, ",", '"')) {
                $suburbData = [];
                $suburb = $this->Suburbs->Regions->find()->where(['Regions.name' => $data[0]])->first();
                $suburbData['region_id'] = ($suburb) ? $suburb->id : 0;
                $suburb_name = $this->Suburbs->find()->where(['name' => $data[1]])->first();
                if ($suburb_name) {
                    $ids[] = $suburbData['id'] = $suburb_name->id;
              }
                $suburb = [
                    'name' => $data[1],
                    'is_deleted' => $data[2],
                    'created_at' => date("Y-m-d H:i:s"),
                    'updated_at' => date("Y-m-d H:i:s")
                ];
                $suburbData = array_merge($suburbData, $suburb);
                $suburbs[] = $suburbData;
            } 
            if (empty($suburbs)) {
                $response[ERRORS][] = NO_IMPORT_RECORD;
            } else if($suburbData['region_id'] == 0)
            {
                $response[ERRORS][] = NO_REGION_EXIST;
            }
            else {
                $suburbToSave = $this->Suburbs->find()->where(['id in' => implode(',', $ids)]);
                $suburbs = $this->Suburbs->patchEntities($suburbToSave, $suburbs);
                if ($this->Suburbs->saveMany($suburbs)) {
                    $response[SUCCESS] = SUBURBS_IMPORTED;
                } else {
                    $response[ERRORS][] = $this->getError($suburbs);
                }
            }
            } else {
                $response[ERRORS][] = INVALID_IMPORT_FILE;
            }
        } else {
            $response[ERRORS][] = CSV_NOT_UPLOADED;
        }
        return $response;
    }
  
    public function importPractices()
    {
        $response = [];
        if ($this->request->getData(CSV_ERROR_FILE)) {
            $response[ERRORS][] = ERROR_IN_CSV;
        } elseif ($this->request->getData(CSV_FILE)) {
            $this->Practices = TableRegistry::get('practices');
            $filename = explode('.', $this->request->getData(CSV_FILE_NAME));
            $extension = $filename[count($filename) - 1];
            if ($extension == 'csv') {
                $handle = fopen($this->request->getData(CSV_FILE), "r");
                $practices = $ids = [];
                $csvHeaders = fgetcsv($handle, 10000, ",", '"');
            if (unserialize(PRACTICES_IMPORT_FIELDS) != $csvHeaders) {
                $response[ERRORS][] = INVALID_IMPORT_FIELDS;
                return $response;
            }
            while ($data = fgetcsv($handle, 10000, ",", '"')) {
                $practiceData = [];
                $region = $this->Practices->Regions->find()->where(['Regions.name' => $data[1]])->first();
                $practiceData['region_id'] = ($region) ? $region->id : 0;
                $suburb = $this->Practices->Suburbs->find()->where(['Suburbs.name' => $data[2], 'region_id' => (($region) ? $region->id : 0)])->first();
				$practiceData['suburb_id'] = ($suburb) ? $suburb->id : 0;
                $practice_name = $this->Practices->find()->where(['name' => $data[0]])->first();
                if ($practice_name) {
                    $ids[] = $practiceData['id'] = $practice_name->id;
                }
                $practice = [
                    'name' => $data[0],
                    'is_deleted' => $data[3],
                    'created_at' => date("Y-m-d H:i:s"),
                    'updated_at' => date("Y-m-d H:i:s")
                ];
                $practiceData = array_merge($practiceData, $practice);
                $practices[] = $practiceData;
            } 
            if (empty($practices)) {
                $response[ERRORS][] = NO_IMPORT_RECORD;
            } else if($practiceData['suburb_id'] == 0)
            {
                $response[ERRORS][] = NO_SUBURB_EXIST;
            }else {
                $practiceToSave = $this->Practices->find()->where(['id in' => implode(',', $ids)]);
                $practices = $this->Practices->patchEntities($practiceToSave, $practices);
                if ($this->Practices->saveMany($practices)) {
                    $response[SUCCESS] = PRACTICES_IMPORTED;
                } else {
                    $response[ERRORS][] = $this->getError($practices);
                }
            }
            } else {
                $response[ERRORS][] = INVALID_IMPORT_FILE;
            }
        } else {
            $response[ERRORS][] = CSV_NOT_UPLOADED;
        }
        return $response;
    }
  
    public function importDoctors()
    {
        $response = [];
        if ($this->request->getData(CSV_ERROR_FILE)) {
            $response[ERRORS][] = ERROR_IN_CSV;
        } elseif ($this->request->getData(CSV_FILE)) {
            $this->Doctors = TableRegistry::get('doctors');
            $filename = explode('.', $this->request->getData(CSV_FILE_NAME));
            $extension = $filename[count($filename) - 1];
            if ($extension == 'csv') {
                $handle = fopen($this->request->getData(CSV_FILE), "r");
                $doctors = $ids = [];
                $csvHeaders = fgetcsv($handle, 10000, ",", '"');
            if (unserialize(DOCTOR_IMPORT_FIELDS) != $csvHeaders) {
                $response[ERRORS][] = INVALID_IMPORT_FIELDS;
                return $response;
            }
                while ($data = fgetcsv($handle, 10000, ",", '"')) {
                $doctorData = [];
                $region = $this->Doctors->Regions->find()->where(['Regions.name' => $data[2]])->first();
                $doctorData['region_id'] = ($region) ? $region->id : 0;
                $suburb = $this->Doctors->Suburbs->find()->where(['Suburbs.name' => $data[3],'region_id' => (($region) ? $region->id : 0)])->first();
                $doctorData['suburb_id'] = ($suburb) ? $suburb->id : 0;
                $practice = $this->Doctors->Practices->find()->where(['Practices.name' => $data[4],'suburb_id' => (($suburb) ? $suburb->id : 0)])->first();
                $doctorData['practice_id'] = ($practice) ? $practice->id : 0;
                $doctor_name = $this->Doctors->find()->where(['first_name' => $data[0]])->first();
                if ($doctor_name) {
                    $ids[] = $doctorData['id'] = $doctor_name->id;
                }
                $doctor = [
                    'first_name' => $data[0],
                    'last_name' => $data[1],
                    'is_deleted' => $data[5],
                    'created_at' => date("Y-m-d H:i:s"),
                    'updated_at' => date("Y-m-d H:i:s")
                ];
                $doctorData = array_merge($doctorData, $doctor);
                $doctors[] = $doctorData;
            } 
            if (empty($doctors)) {
                $response[ERRORS][] = NO_IMPORT_RECORD;
            } else if($doctorData['practice_id'] == 0)
            {
                $response[ERRORS][] = NO_PRACTICE_EXIST;
            }else if($doctorData['suburb_id'] == 0)
            {
                $response[ERRORS][] = NO_SUBURB_EXIST;
            }else {
                $doctorToSave = $this->Doctors->find()->where(['id in' => implode(',', $ids)]);
                $doctors = $this->Doctors->patchEntities($doctorToSave, $doctors);
                if ($this->Doctors->saveMany($doctors)) {
                    $response[SUCCESS] = DOCTORS_IMPORTED;
                } else {
                    $response[ERRORS][] = $this->getError($doctors);
                }
            }
            } else {
                $response[ERRORS][] = INVALID_IMPORT_FILE;
            }
        } else {
            $response[ERRORS][] = CSV_NOT_UPLOADED;
        }
        return $response;
    }
  
    public function importRegions()
    {
        $response = [];
        if ($this->request->getData(CSV_ERROR_FILE)) {
            $response[ERRORS][] = ERROR_IN_CSV;
        } elseif ($this->request->getData(CSV_FILE)) {
            $this->Regions = TableRegistry::get('regions');
            $filename = explode('.', $this->request->getData(CSV_FILE_NAME));
            $extension = $filename[count($filename) - 1];
            if ($extension == 'csv') {
                $handle = fopen($this->request->getData(CSV_FILE), "r");
                $regions = $ids = [];
                $csvHeaders = fgetcsv($handle, 10000, ",", '"');
            if (unserialize(REGIONS_IMPORT_FIELDS) != $csvHeaders) {
                $response[ERRORS][] = INVALID_IMPORT_FIELDS;
                return $response;
            }
            while ($data = fgetcsv($handle, 10000, ",", '"')) {
                $region = $this->Regions->find()->where(['name' => $data[0]])->first();
                $regionData = [];
                if ($region) {
                    $ids[] = $regionData['id'] = $region->id;
                } 
                $region = [
                    'name' => $data[0],
                    'is_deleted' => $data[1],
                    'created_at' => date("Y-m-d H:i:s"),
                    'updated_at' => date("Y-m-d H:i:s")
                ];
                $regionData = array_merge($regionData, $region);
                $regions[] = $regionData;
            } 
            if (empty($regions)) {
                $response[ERRORS][] = NO_IMPORT_RECORD;
            } else {
                $regionToSave = $this->Regions->find()->where(['id in' => implode(',', $ids)]);
                $regions = $this->Regions->patchEntities($regionToSave, $regions);
                if ($this->Regions->saveMany($regions)) {
                    $response[SUCCESS] = REGIONS_IMPORTED;
                } else {
                    $response[ERRORS][] = $this->getError($regions);
                }
            }
            } else {
                $response[ERRORS][] = INVALID_IMPORT_FILE;
            }
        } else {
            $response[ERRORS][] = CSV_NOT_UPLOADED;
        }
        return $response;
    }
  /**
   * @param $modelData
   * @return mixed
   */
    public function getError($modelData)
    {
        $error = "";
        foreach ($modelData as $key => $value) {
            $fields = [];
            if (!empty($value->errors())) {
                $error = 'Error in row :' . ($key + 2) . '. Invalid fields: ';
                foreach ($value->errors() as $key => $value) {
                    $key = str_replace(['practice_id', 'suburb_id','region_id'], ['practice', 'suburb','region'], $key);
                $fields[] = $key;
                }
                $error .= implode(', ', $fields);
            }
        }
        return $error;
    }

}

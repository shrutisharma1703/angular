<?php
namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\ORM\TableRegistry;
use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;
use Cake\Event\Event;

class CommonComponent extends Component
{  

    public $components = array(
        'Amazon',
        'Resize',
    );          
    /**
    * @var string
    */
    public $SECRET_KEY = "QrsMtr0tAuy1vzajYbE1vk0c0VBVXKsPfCpxkL4y";
    /**
    * @var string
    */
    public $KEY = "AKIAI4KTWTEZGUK7CQXQ";
    
    /**
    * Amazon Upload functionality.
    *
    * @param integer $localpath_reviews
    * @param string $reviews_bucket
    * @param string $alt
    * @param string $fileName
    * @return @void
    */
    public function amazonUpload($localpath, $bucket, $fileName, $alt)
    {
        $s3 = S3Client::factory([
            'credentials' => [
                'key' => AWS_KEY,
                'secret' => AWS_SECRET_KEY,
            ],
            'endpoint' => AWS_ENDPOINT,
        ]);
        try {
        $s3->putObject(array(
            'Bucket' => $bucket,
            'Key' => $fileName,
            'SourceFile' => $localpath,
            'Secret' => $this->SECRET_KEY,
            'Body' => '',
            'ServerSideEncryption' => 'AES256',
            'Metadata' => array(
            'alt' => $alt,
            ),
        ));
        
        } catch (S3Exception $e) {
            echo "There was an error uploading the file.\n" . $e . "<br/>";
        }   
    }
    //  to access video in private folder
    public function readVideo($bucket,$fileName){
		
		$video = S3Client::factory([
            'credentials' => [
                'key' => AWS_KEY,
                'secret' => AWS_SECRET_KEY,
            ],
            'endpoint' => AWS_ENDPOINT,
        ]);
        
        $presignedUrl = $video->getObjectUrl($bucket,$fileName,'+1440 minutes');
        return $presignedUrl;
    }
    /**
    * Amazon Video Upload functionality.
    *
    * @param string $filetemp
    * @param string $file
    * @param integer $size
    * @param string $extension
    * @param string $localpath
    * @param string $alt
    * @return @void
    */
    public function awsPackshotUpload($filetemp, $file, $size, $extension, $localpath, $type,$alt = '')
    {
        if($type == 0){
            $this->amazonUpload($filetemp,AWS_BUCKET_DEV,PACKSHOT_BUCKET.DIRECTORY_SEPARATOR.'pdf'.DIRECTORY_SEPARATOR.$file,$alt);
        }
        else{
            $this->amazonUpload($filetemp,AWS_BUCKET_DEV,PACKSHOT_BUCKET.DIRECTORY_SEPARATOR.'video'.DIRECTORY_SEPARATOR.$file,$alt); 
        }       
    }
    
    public function awsMenuUpload($filetemp, $file, $size, $extension, $localpath, $type,$alt = '')
    {
        if($type == 0){
            $this->amazonUpload($filetemp,AWS_BUCKET_DEV,MENU_BUCKET.DIRECTORY_SEPARATOR.'pdf'.DIRECTORY_SEPARATOR.$file,$alt);
        }
        else{
            $this->amazonUpload($filetemp,AWS_BUCKET_DEV,MENU_BUCKET.DIRECTORY_SEPARATOR.'video'.DIRECTORY_SEPARATOR.$file,$alt); 
        }       
    }
    
    public function awsBrandUpload($filetemp, $file, $size, $extension, $localpath, $type,$alt = '')
    {
        $this->amazonUpload($filetemp,AWS_BUCKET_DEV,BRAND_BUCKET.DIRECTORY_SEPARATOR.$file,$alt);    
    }
  /**
   * Method description
   *
   * File parameters return function
   *
   * @param array $file
   * @return array $file
   */
    public function imageFileValues($files = array())
    {
        $file = array();
        $file['name'] = '';

        if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $files['name'])) {
            $file['name'] = time() . '-' . preg_replace('/[^a-zA-Z0-9.]+/', '', $files['name']);
            $file['name'] = str_replace(' ', '_', $file['name']);
        } else {

            $file['name'] = str_replace(' ', '_', $files['name']);
            $file['name'] = time() . '-' . $file['name'];
        }

        $file['tmp_name'] = $files['tmp_name'];
        $file['size'] = $files['size'];
        $file['ext'] = pathinfo($file['name'], PATHINFO_EXTENSION);
        return $file;
    }

    public function siteUrl()
    {
        return sprintf(
            "%s://%s%s",
            isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
            $_SERVER['SERVER_NAME'],
            $_SERVER['REQUEST_URI']
        );
    }

  /**
   * Method description
   *
   * Method is used to generate Auth token
   *
   * @param length
   *
   * @return string
   */
    public function generateRandomString($length = 16, $password = '')
    {

        // initialize variables
        $i = 0;
        $possible = "0123456789abcdefghijklmnopqrstuvwxyz";
        while ($i < $length) {
            $char = substr($possible, mt_rand(0, strlen($possible) - 1), 1);

            if (!strstr($password, $char)) {
                $password .= $char;
                $i++;
            }
        }
        return $password;
    }

  /**
   * This function is used to resize images
   * @param string, string, int, int
   * @return string
   * @author
   */
   
    public function resize($imagePath, $targetfile, $size = 200)
    {
        //$sourcefile, $size, $targetfile
        $destinationWidth = $size;
        $destinationHeight = $size;
        // The file has to exist to be resized
        if (file_exists($imagePath)) {

            // Gather some info about the image
            $imageInfo = getimagesize($imagePath);

            // Find the intial size of the image
            $sourceWidth = $imageInfo[0];
            $sourceHeight = $imageInfo[1];

            // Find the mime type of the image
            $mimeType = $imageInfo['mime'];

            $source_aspect_ratio = $sourceWidth / $sourceHeight;
            $thumbnail_aspect_ratio = $destinationWidth / $destinationHeight;
            if ($sourceWidth <= $destinationWidth && $sourceHeight <= $destinationHeight) {
                $thumbnail_image_width = $sourceWidth;
                $thumbnail_image_height = $sourceHeight;
            } elseif ($thumbnail_aspect_ratio > $source_aspect_ratio) {
                $thumbnail_image_width = (int) ($destinationHeight * $source_aspect_ratio);
                $thumbnail_image_height = $destinationHeight;
            } else {
                $thumbnail_image_width = $destinationWidth;
                $thumbnail_image_height = (int) ($destinationWidth / $source_aspect_ratio);
            }

            // Create the destination for the new image
            $destination = imagecreatetruecolor($thumbnail_image_width, $thumbnail_image_height);

            // Now determine what kind of image it is and resize it appropriately
            if ($mimeType == 'image/jpeg' || $mimeType == 'image/pjpeg') {
                $source = imagecreatefromjpeg($imagePath);
                imagecopyresampled($destination, $source, 0, 0, 0, 0, $thumbnail_image_width, $thumbnail_image_height, $sourceWidth, $sourceHeight);
                imagejpeg($destination, $targetfile, 100);
            } else if ($mimeType == 'image/gif') {
                $source = imagecreatefromgif($imagePath);
                imagecopyresampled($destination, $source, 0, 0, 0, 0, $thumbnail_image_width, $thumbnail_image_height, $sourceWidth, $sourceHeight);
                imagegif($destination, $targetfile, 100);
            } else if ($mimeType == 'image/png' || $mimeType == 'image/x-png') {
                $source = imagecreatefrompng($imagePath);
                imagealphablending($destination, false);
                imagesavealpha($destination, true);
                $transparent = imagecolorallocatealpha($destination, 255, 255, 255, 127);
                imagefilledrectangle($destination, 0, 0, $thumbnail_image_width, $thumbnail_image_height, $transparent);
                imagecopyresampled($destination, $source, 0, 0, 0, 0, $thumbnail_image_width, $thumbnail_image_height, $sourceWidth, $sourceHeight);
                imagepng($destination, $targetfile, 9);
                } else {
                return false;
                }

            // Free up memory
            imagedestroy($source);
            imagedestroy($destination);
            return true;
            } else {
            return false;
            }

    }
  
  /**
   * Amazon Image Upload functionality.
   *
   * @param string $filetemp
   * @param string $file
   * @param integer $size
   * @param string $extension
   * @param string $localpath
   * @param string $alt
   * @return @void
   */
   //image upload 
    public function imageFileUpload($filetemp, $file, $size, $extension, $localpath, $alt = '')
    {
        $move = move_uploaded_file($filetemp, IMAGE_PATH . $localpath . '/' . $file);
        if (!$move) {
            throw new Exception("File Didn't Upload");
        } else {      
            return true;
        }
    }
    //pdf upload
    public function imagePdfUpload($filetemp, $file, $size, $extension, $localpath, $alt = '')
    {
        $move = move_uploaded_file($filetemp, PDF_PATH . $localpath . '/' . $file);
        if (!$move) {
            throw new Exception("File Didn't Upload");
        } else {      
            return true;
        }
    }
    
   /*
   * Total Number of records
   * 
   * */
    public function totalRecords($modelname){
      
        $this->ModelName = TableRegistry::get($modelname);
        return $this->ModelName->find()->count();  
    }
   /*
   * Name of table records
   * 
   * */
    public function fetchName($modelname, $id, $fieldname){
      
        $this->ModelName = TableRegistry::get($modelname);
        $table_value = $this->ModelName->find()->where(['id' => $id])->first();     
        return $table_value->$fieldname;  
    }
	
   /*
   * Name of fetch menu name 
   * 
   * */
    public function fetchMenuName($modelname, $id, $fieldname){
      
        $this->ModelName = TableRegistry::get($modelname);
        $table_value = $this->ModelName->find()->where(['brand_id' => $id])->first();
        if(!empty($table_value)){
            return $table_value->$fieldname; 
        }else{
            return '-';
        }
    }
  
   /*
   * Name of fetch menu parent name 
   * 
   * */
    public function fetchParentName($modelname, $id, $fieldname){
      
        $this->ModelName = TableRegistry::get($modelname);
        $table_value = $this->ModelName->find()->where(['menues_id' => $id])->first();  
        return $table_value->$fieldname;  
    }
   /*
   * Name of table records
   * 
   * */
    public function fetchList($modelname, $fieldname, $value){
      
        $this->ModelName = TableRegistry::get($modelname);
        if($modelname == 'Doctors' || $modelname == 'Users'){
            $table_value = $this->ModelName->find('list',[
                            'keyField' => 'id',
                            'valueField' => function ($row) {
                                            return $row['first_name'] . ' ' . $row['last_name'];
                                        }
                        ])->where([$fieldname => $value]);
        }
        else{       
            $table_value = $this->ModelName->find('list')->where([$fieldname => $value]);       
        }
        return $table_value;  
    }
  
   /*
   * Name of table records
   * 
   * */
    public function menuesFetchList($modelname, $fieldname, $value){
        
        $this->ModelName = TableRegistry::get($modelname);
        return $this->ModelName->find('list',[
                            'keyField' => 'brand_id',
                            'valueField' => function ($row) {
                                            return $row['brand_name'];
                                        }
                        ])->where([$fieldname => $value]);
          
    }
  
}

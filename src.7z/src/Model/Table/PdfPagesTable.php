<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * PdfPages Model
 *
 *
 */
class PdfPagesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('pdf_pages');
        $this->setPrimaryKey('id');      
        $this->hasMany('PdfPageClicks', [
           'foreignKey' => 'page_id'
        ]);
    } 
}

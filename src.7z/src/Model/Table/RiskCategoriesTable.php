<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * RiskCategories Model
 *
 * @property \Cake\ORM\Association\HasMany $RiskSubCategories
 *
 * @method \App\Model\Entity\RiskCategory get($primaryKey, $options = [])
 * @method \App\Model\Entity\RiskCategory newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\RiskCategory[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\RiskCategory|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\RiskCategory patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\RiskCategory[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\RiskCategory findOrCreate($search, callable $callback = null, $options = [])
 */
class RiskCategoriesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('risk_categories');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');

        $this->hasMany('RiskSubCategories', [
            'foreignKey' => 'risk_category_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->allowEmpty('name');

        $validator
            ->integer('is_deleted')
            ->allowEmpty('is_deleted');

        $validator
            ->dateTime('created_at')
            ->allowEmpty('created_at');

        $validator
            ->dateTime('modified_at')
            ->allowEmpty('modified_at');

        return $validator;
    }
}

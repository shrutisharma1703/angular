<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * PdfPageClicks Model
 *
 *
 */
class PdfPageClicksTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->setTable('pdf_page_clicks');
        $this->setPrimaryKey('id');
        $this->belongsTo('Pdfs', [
             'foreignKey' => 'pdf_id'
        ]);       
    }
}

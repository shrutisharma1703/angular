<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\I18n\Time;

/**
 * Practices Model
 *
 * @method \App\Model\Entity\Practice get($primaryKey, $options = [])
 * @method \App\Model\Entity\Practice newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Practice[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Practice|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Practice patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Practice[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Practice findOrCreate($search, callable $callback = null, $options = [])
 */
class PracticesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('practices');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');
		$this->belongsTo('Regions', [
            'foreignKey' => 'region_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Suburbs', [
            'foreignKey' => 'suburb_id'
        ]);
        $this->hasMany('Doctors', [
            'foreignKey' => 'practice_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->notEmpty('name', 'Please provide a Practice name')
            ->add('name', [
                'minLength' =>
            [
                'rule' => ['minLength', 2],
                MESSAGE => 'Practice name must have atleast 2 characters',
            ],
            'maxLength' =>
            [
                'rule' => ['maxLength', 50],
                MESSAGE => 'Practice name cannot be too long.',
            ],     
        ]);
        
        $validator
            ->integer('suburb_id')
            ->notEmpty('suburb_id');
            
        $validator
            ->integer('region_id')
            ->notEmpty('region_id');

        $validator
            ->integer('is_deleted')
            ->allowEmpty('is_deleted');

        $validator
            ->dateTime('created_at')
            ->allowEmpty('created_at');

        $validator
            ->dateTime('updated_at')
            ->allowEmpty('updated_at');

        return $validator;
    }
 
}

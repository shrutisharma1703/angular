<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Packshots Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Packshots
 * @property \Cake\ORM\Association\BelongsTo $Brands
 * @property \Cake\ORM\Association\BelongsTo $Menues
 * 
 * @method \App\Model\Entity\Packshot get($primaryKey, $options = [])
 * @method \App\Model\Entity\Packshot newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Packshot[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Packshot|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Packshot patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Packshot[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Packshot findOrCreate($search, callable $callback = null, $options = [])
 */
class PackshotsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('packshots');
        $this->setDisplayField('name');
        $this->setPrimaryKey('packshot_id');

        $this->belongsTo('Packshots', [
            'foreignKey' => 'packshot_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Brands', [
            'foreignKey' => 'brand_id'
        ]);
        $this->belongsTo('Menues', [
            'foreignKey' => 'brand_id'
        ]);
    }                

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->notEmpty('name', 'Please provide a name')
            ->add('name', [
                'minLength' =>
            [
                'rule' => ['minLength', 3],
                MESSAGE => 'Name must have atleast 3 characters',
            ],
            'maxLength' =>
            [
                'rule' => ['maxLength', 50],
                MESSAGE => 'Name cannot be too long.',
            ],       
            ]);
      
        $validator
            ->integer('brand_id')
            ->notEmpty('brand_id');
            
        $validator
            ->notEmpty('file_path');

        $validator
            ->integer('is_deleted')
            ->allowEmpty('is_deleted');
            
        $validator
            ->integer('file_type')
            ->notEmpty('file_type');

        $validator
            ->dateTime('created_at')
            ->allowEmpty('created_at');

        $validator
            ->dateTime('updated_at')
            ->allowEmpty('updated_at');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['packshot_id'], 'Packshots'));
        $rules->add($rules->existsIn(['brand_id'], 'Brands'));
        return $rules;
    }
}

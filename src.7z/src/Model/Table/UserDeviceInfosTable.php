<?php
namespace App\Model\Table;

use ArrayObject;
use Cake\Event\Event;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * UserDeviceInfos Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Users
 *
 * @method \App\Model\Entity\UserDeviceInfo get($primaryKey, $options = [])
 * @method \App\Model\Entity\UserDeviceInfo newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\UserDeviceInfo[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\UserDeviceInfo|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\UserDeviceInfo patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\UserDeviceInfo[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\UserDeviceInfo findOrCreate($search, callable $callback = null, $options = [])
 */
class UserDeviceInfosTable extends Table
{

  /**
   * Initialize method
   *
   * @param array $config The configuration for the Table.
   * @return void
   */
  public function initialize(array $config)
  {
    parent::initialize($config);

    $this->setTable('user_device_infos');
    $this->setDisplayField('id');
    $this->setPrimaryKey('id');

    $this->belongsTo('Users', [
      'foreignKey' => 'user_id',
      'joinType' => 'INNER',
    ]);
  }

  /**
   * Default validation rules.
   *
   * @param \Cake\Validation\Validator $validator Validator instance.
   * @return \Cake\Validation\Validator
   */
  public function validationDefault(Validator $validator)
  {
    $validator
      ->integer('id')
      ->allowEmpty('id', 'create');

    $validator
      ->notEmpty('device_type');

    $validator
      ->allowEmpty('device_token');

    $validator
      ->allowEmpty('auth_token');

    $validator
      ->dateTime('login_date');

    $validator
      ->dateTime('auth_token_expire_date');

    return $validator;
  }

  /**
   * Returns a rules checker object that will be used for validating
   * application integrity.
   *
   * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
   * @return \Cake\ORM\RulesChecker
   */
  public function buildRules(RulesChecker $rules)
  {
    $rules->add($rules->existsIn(['user_id'], 'Users'));

    return $rules;
  }

  /**
   * Trim Request Data Before Building Entities
   *
   * @param ArrayObject $event
   * @param \Cake\Event\Event $data Request object
   * @param ArrayObject $options
   * @return Object Request object
   */
  public function beforeMarshal(Event $event, ArrayObject $data, ArrayObject $options)
  {
    foreach ($data as $key => $value) {
      if (is_string($value)) {
        $data[$key] = trim($value);
      }
    }
  }
}

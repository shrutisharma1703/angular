<?php
namespace App\Model\Table;

use ArrayObject;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Event\Event;
use Cake\I18n\Time;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\ORM\RulesChecker;
use Cake\ORM\TableRegistry;

/**
 * Users Model
 *
 * @property \Cake\ORM\Association\HasMany $PdfClicks
 * @property \Cake\ORM\Association\HasMany $PdfPageClicks
 * @property \Cake\ORM\Association\HasMany $SelectedExperts
 * @property \Cake\ORM\Association\HasMany $UserDeviceInfos
 * @property \Cake\ORM\Association\HasMany $UserProfiles
 * @property \Cake\ORM\Association\BelongsToMany $Brands
 *
 * @method \App\Model\Entity\User get($primaryKey, $options = [])
 * @method \App\Model\Entity\User newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\User[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\User|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\User patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\User[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\User findOrCreate($search, callable $callback = null, $options = [])
 */
class UsersTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
       parent::initialize($config);

        $this->setTable('users');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->hasMany('UserDeviceInfos', [
            'foreignKey' => 'user_id'
        ]);
        $this->hasMany('UserProfiles', [
            'foreignKey' => 'user_id'
        ]);
        $this->belongsToMany('Brands', [
            'foreignKey' => 'user_id',
            'targetForeignKey' => 'brand_id',
            'joinTable' => 'users_brands'
        ]);
        $this->belongsToMany('Doctors', [
            'foreignKey' => 'user_id',
            'targetForeignKey' => 'doctor_id',
            'joinTable' => 'users_doctors'
        ]);
    }
    
    
    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->notEmpty('first_name');

        $validator
            ->requirePresence('last_name', 'create')
            ->allowEmpty('last_name');

        $validator
            ->notEmpty('username');
           
        $validator
            ->email('email', 'create')
            ->requirePresence('email', 'create')
            ->notEmpty('email');

        $validator
           ->requirePresence('password', 'create')
            ->notEmpty('password');
        $validator
            ->allowEmpty('new_password');
        $validator
            ->allowEmpty('password_change');
            
        return $validator;
    }

    /**
     * Add Additional Validation
     *
     * 
     */    
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->isUnique(['username'],
            'Username is already in use.'
        ));
        $rules->add($rules->isUnique(['email'],
            'Email is already in use.'
        ));
        return $rules;
    }
    /**
    * Compare two password strings
    *
    * @param String $verifyString The value to be checked.
    * @param String $password
    * @return Boolean
    */
    public function checkPassword($verifyString, $password)
    {
        return (new DefaultPasswordHasher)->check($verifyString, $password);
    }
 
    /**
   * Verify Direct Login
   *
   * @param Array $userData
   * @return Array
   */
    public function verifyDirectLogin($userData)
    {
		$json = [];
        $user = $this->find()->select(['id', 'password', 'role'])
			->where(['username' => $userData['username']])->first();
        if (is_null($user)) {
            $json = array(
                STATUS => INVALID_CREDENTIALS_CODE,
                MESSAGE => INVALID_CREDENTIALS_MESSAGE,
            );
        } else {
        if($user->role == 0){
            $json = $this->message(INVALID_CREDENTIALS_CODE_SERVICE,INVALID_CREDENTIALS_MSG);
        }else if ($this->checkPassword($userData['password'], $user->password)) {
            $userDeviceInfo = $this->UserDeviceInfos->find()->where(['device_id' => $userData['user_device_infos'][0]['device_id'], 'user_id' => $user->id])->first();
            if (!is_null($userDeviceInfo)) {
                $deviceInfo = array(	
                    'user_id' => $user->id,
                    'login_date' => Time::now(),
                    'auth_token_expire_date' => new Time('+30 days'),
                );
				$userDeviceInfo = $this->UserDeviceInfos->patchEntity($userDeviceInfo, $deviceInfo);
            }else {
                $deviceInfo = array(
                                    'auth_token' => $this->generateRandomString('32'),              
                                    'user_id' => $user->id,
                                    'login_date' => Time::now(),
                                    'auth_token_expire_date' => new Time('+30 days'),
                                    );    
           
                if(!empty($userData['user_device_infos'][0]['device_id'])){
                    $deviceInfo['device_id']= $userData['user_device_infos'][0]['device_id'];
                }
                if(!empty($userData['user_device_infos'][0]['device_token'])){
                    $deviceInfo['device_token'] = $userData['user_device_infos'][0]['device_token'];
                }
                if(!empty($userData['user_device_infos'][0]['device_type'])){
                    $deviceInfo['device_type'] = $userData['user_device_infos'][0]['device_type'];
                }
           
				$userDeviceInfo = $this->UserDeviceInfos->newEntity($deviceInfo);
            }
            //Save device token 
            $this->UserDeviceInfos->save($userDeviceInfo);
            //User data         
            $user = $this->find()->where(['id' => $user->id])->first();  
            $userDeviceInfo = $this->UserDeviceInfos->find()->where(['device_id' => $userData['user_device_infos'][0]['device_id'], 'user_id' => $user->id])->first();
            $user['user_device_infos'] = $userDeviceInfo;
            if( $user->image_path){
                $user->image_path = SITE_URL.'images/users/'.$user->image_path;
            }
            if($user->id){
				//for brands
                $brands = TableRegistry::get('users_brands');
                $brandsId = $brands->find('all')->select('brand_id')->where(['user_id' => $user->id])->toArray();
                $brandIds = array();
                foreach($brandsId as $brandId){
                    $brandIds[] = $brandId['brand_id']; 
                }
                $brandList = implode(', ', $brandIds);
                // for doctors
                $doctors = TableRegistry::get('users_doctors');
                $doctorsId = $doctors->find('all')->select('doctor_id')->where(['user_id' => $user->id])->toArray();
                $doctorIds = array();
                foreach($doctorsId as $doctorId){
                    $doctorIds[] = $doctorId['doctor_id']; 
                }
                $doctorList = implode(', ', $doctorIds);
                
            }
            $user['brand_ids'] = $brandList;
            $user['doctor_ids'] = $doctorList;
            $json = array(
                STATUS => SUCCESSCODE,
                MESSAGE => SUCCESS,
                RESPONSE => $user->toArray(),
            );
          
        } else {
          $json = $this->message(INVALID_CREDENTIALS_CODE,INVALID_CREDENTIALS_MESSAGE);
        } 
    }
    return $json;
  }

    /* return values*/
    public function message($status , $message)
    {
        return array('status' => $status,'message' => $message);
    }
      /**
   * Method description
   *
   * Method is used to generate Auth token
   *
   * @param length
   *
   * @return string
   */
    public function generateRandomString($length = 16, $password = '')
    {

        // initialize variables
        $i = 0;
        $possible = "0123456789abcdefghijklmnopqrstuvwxyz";
        while ($i < $length) {
            $char = substr($possible, mt_rand(0, strlen($possible) - 1), 1);

            if (!strstr($password, $char)) {
                $password .= $char;
                $i++;
            }
        }
        return $password;
    }

    /**
     * Trim Request Data Before Building Entities
     *
     * @param ArrayObject $event
     * @param \Cake\Event\Event $data Request object
     * @param ArrayObject $options
     * @return Object Request object
     */
    public function beforeMarshal(Event $event, ArrayObject $data, ArrayObject $options)
    {
        foreach ($data as $key => $value) {
            if (is_string($value)) {
                $data[$key] = trim($value);
            }
        }
    }
    
}

<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Risk Entity
 *
 * @property int $id
 * @property string $risk
 * @property string $risk_type
 * @property string $recommendation
 * @property \Cake\I18n\Time $created_at
 * @property \Cake\I18n\Time $modified_at
 *
 * @property \App\Model\Entity\RiskSubCategory[] $risk_sub_categories
 */
class Risk extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];
}
